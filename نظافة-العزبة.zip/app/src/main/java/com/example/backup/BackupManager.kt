package com.example.backup

import com.example.data.local.AppDatabase
import com.example.data.local.entity.AbsenceEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.CleaningAreaEntity
import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.DailyPlanEntity
import com.example.data.local.entity.PersonEntity
import com.example.data.local.entity.SmsAttemptEntity
import com.example.data.local.entity.SmsOutboxEntity
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class BackupPreview(
    val schemaVersion: Int,
    val exportedAt: String,
    val peopleCount: Int,
    val areasCount: Int,
    val tasksCount: Int,
    val plansCount: Int,
    val assignmentsCount: Int,
    val absencesCount: Int,
    val messagesCount: Int,
    val isValid: Boolean,
    val errorMessage: String? = null
)

object BackupManager {

    suspend fun exportDatabaseToJson(database: AppDatabase): String {
        val root = JSONObject()
        root.put("schemaVersion", 1)
        root.put("exportedAt", SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).format(Date()))
        root.put("appVersion", "1.0.0")

        val data = JSONObject()

        // People
        val peopleArr = JSONArray()
        for (p in database.personDao().getAllSync()) {
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("name", p.name)
            obj.put("phoneNumber", p.phoneNumber)
            obj.put("isActive", p.isActive)
            obj.put("notes", p.notes ?: "")
            obj.put("createdAt", p.createdAt)
            obj.put("updatedAt", p.updatedAt)
            peopleArr.put(obj)
        }
        data.put("people", peopleArr)

        // Areas
        val areasArr = JSONArray()
        for (a in database.areaDao().getAllSync()) {
            val obj = JSONObject()
            obj.put("id", a.id)
            obj.put("name", a.name)
            obj.put("description", a.description ?: "")
            obj.put("isActive", a.isActive)
            obj.put("createdAt", a.createdAt)
            obj.put("updatedAt", a.updatedAt)
            areasArr.put(obj)
        }
        data.put("areas", areasArr)

        // Tasks
        val tasksArr = JSONArray()
        for (t in database.taskDao().getAllSync()) {
            val obj = JSONObject()
            obj.put("id", t.id)
            obj.put("areaId", t.areaId)
            obj.put("name", t.name)
            obj.put("instructions", t.instructions ?: "")
            obj.put("effortPoints", t.effortPoints)
            obj.put("estimatedMinutes", t.estimatedMinutes ?: 30)
            obj.put("requiredPeople", t.requiredPeople)
            obj.put("isActive", t.isActive)
            obj.put("recurrenceRule", t.recurrenceRule ?: "DAILY")
            obj.put("createdAt", t.createdAt)
            obj.put("updatedAt", t.updatedAt)
            tasksArr.put(obj)
        }
        data.put("tasks", tasksArr)

        // Plans
        val plansArr = JSONArray()
        for (pl in database.scheduleDao().getAllPlansSync()) {
            val obj = JSONObject()
            obj.put("id", pl.id)
            obj.put("planDate", pl.planDate)
            obj.put("status", pl.status)
            obj.put("version", pl.version)
            obj.put("createdAt", pl.createdAt)
            obj.put("approvedAt", pl.approvedAt ?: 0L)
            obj.put("notes", pl.notes ?: "")
            plansArr.put(obj)
        }
        data.put("plans", plansArr)

        // Assignments
        val assignArr = JSONArray()
        for (asg in database.scheduleDao().getAllAssignmentsSync()) {
            val obj = JSONObject()
            obj.put("id", asg.id)
            obj.put("planId", asg.planId)
            obj.put("taskId", asg.taskId)
            obj.put("personId", asg.personId)
            obj.put("assignmentDate", asg.assignmentDate)
            obj.put("effortPointsSnapshot", asg.effortPointsSnapshot)
            obj.put("status", asg.status)
            obj.put("assignedAt", asg.assignedAt)
            obj.put("completedAt", asg.completedAt ?: 0L)
            obj.put("completionSource", asg.completionSource ?: "")
            obj.put("notes", asg.notes ?: "")
            assignArr.put(obj)
        }
        data.put("assignments", assignArr)

        // Absences
        val absArr = JSONArray()
        for (ab in database.absenceDao().getAllSync()) {
            val obj = JSONObject()
            obj.put("id", ab.id)
            obj.put("personId", ab.personId)
            obj.put("startDate", ab.startDate)
            obj.put("endDate", ab.endDate)
            obj.put("reason", ab.reason ?: "")
            obj.put("createdAt", ab.createdAt)
            absArr.put(obj)
        }
        data.put("absences", absArr)

        // Messages
        val msgArr = JSONArray()
        for (m in database.smsDao().getAllOutboxSync()) {
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("assignmentId", m.assignmentId ?: "")
            obj.put("personId", m.personId)
            obj.put("recipientPhoneSnapshot", m.recipientPhoneSnapshot)
            obj.put("bodySnapshot", m.bodySnapshot)
            obj.put("status", m.status)
            obj.put("attemptCount", m.attemptCount)
            obj.put("createdAt", m.createdAt)
            obj.put("sentAt", m.sentAt ?: 0L)
            obj.put("deliveredAt", m.deliveredAt ?: 0L)
            obj.put("lastErrorCode", m.lastErrorCode ?: "")
            obj.put("lastErrorMessage", m.lastErrorMessage ?: "")
            obj.put("idempotencyKey", m.idempotencyKey)
            msgArr.put(obj)
        }
        data.put("messages", msgArr)

        // Attempts
        val attemptsArr = JSONArray()
        for (att in database.smsDao().getAllAttemptsSync()) {
            val obj = JSONObject()
            obj.put("id", att.id)
            obj.put("messageId", att.messageId)
            obj.put("attemptNumber", att.attemptNumber)
            obj.put("startedAt", att.startedAt)
            obj.put("finishedAt", att.finishedAt ?: 0L)
            obj.put("result", att.result)
            obj.put("platformResultCode", att.platformResultCode ?: 0)
            obj.put("errorSummary", att.errorSummary ?: "")
            attemptsArr.put(obj)
        }
        data.put("messageAttempts", attemptsArr)

        // Audit
        val auditArr = JSONArray()
        for (aud in database.auditDao().getAllSync()) {
            val obj = JSONObject()
            obj.put("id", aud.id)
            obj.put("eventType", aud.eventType)
            obj.put("entityType", aud.entityType)
            obj.put("entityId", aud.entityId)
            obj.put("details", aud.details)
            obj.put("createdAt", aud.createdAt)
            auditArr.put(obj)
        }
        data.put("auditEvents", auditArr)

        root.put("data", data)
        return root.toString(2)
    }

    fun inspectBackup(jsonString: String): BackupPreview {
        return try {
            val root = JSONObject(jsonString)
            val version = root.optInt("schemaVersion", 0)
            if (version < 1) {
                return BackupPreview(0, "", 0, 0, 0, 0, 0, 0, 0, false, "إصدار المخطط غير مدعوم أو غير صالح")
            }

            val exportedAt = root.optString("exportedAt", "غير محدد")
            val data = root.optJSONObject("data") ?: return BackupPreview(version, exportedAt, 0, 0, 0, 0, 0, 0, 0, false, "لا يحتوي الملف على كائن البيانات data")

            val peopleCount = data.optJSONArray("people")?.length() ?: 0
            val areasCount = data.optJSONArray("areas")?.length() ?: 0
            val tasksCount = data.optJSONArray("tasks")?.length() ?: 0
            val plansCount = data.optJSONArray("plans")?.length() ?: 0
            val assignmentsCount = data.optJSONArray("assignments")?.length() ?: 0
            val absencesCount = data.optJSONArray("absences")?.length() ?: 0
            val messagesCount = data.optJSONArray("messages")?.length() ?: 0

            BackupPreview(
                schemaVersion = version,
                exportedAt = exportedAt,
                peopleCount = peopleCount,
                areasCount = areasCount,
                tasksCount = tasksCount,
                plansCount = plansCount,
                assignmentsCount = assignmentsCount,
                absencesCount = absencesCount,
                messagesCount = messagesCount,
                isValid = true,
                errorMessage = null
            )
        } catch (e: Exception) {
            BackupPreview(0, "", 0, 0, 0, 0, 0, 0, 0, false, "صيغة JSON غير صحيحة: ${e.message}")
        }
    }

    suspend fun restoreDatabaseFromJson(database: AppDatabase, jsonString: String): Pair<Boolean, String> {
        val inspection = inspectBackup(jsonString)
        if (!inspection.isValid) {
            return Pair(false, inspection.errorMessage ?: "الملف غير صالح")
        }

        return try {
            val root = JSONObject(jsonString)
            val data = root.getJSONObject("data")

            val people = mutableListOf<PersonEntity>()
            val peopleArr = data.optJSONArray("people")
            if (peopleArr != null) {
                for (i in 0 until peopleArr.length()) {
                    val obj = peopleArr.getJSONObject(i)
                    people.add(
                        PersonEntity(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            phoneNumber = obj.getString("phoneNumber"),
                            isActive = obj.optBoolean("isActive", true),
                            notes = obj.optString("notes", null),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            val areas = mutableListOf<CleaningAreaEntity>()
            val areasArr = data.optJSONArray("areas")
            if (areasArr != null) {
                for (i in 0 until areasArr.length()) {
                    val obj = areasArr.getJSONObject(i)
                    areas.add(
                        CleaningAreaEntity(
                            id = obj.getString("id"),
                            name = obj.getString("name"),
                            description = obj.optString("description", null),
                            isActive = obj.optBoolean("isActive", true),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            val tasks = mutableListOf<CleaningTaskEntity>()
            val tasksArr = data.optJSONArray("tasks")
            if (tasksArr != null) {
                for (i in 0 until tasksArr.length()) {
                    val obj = tasksArr.getJSONObject(i)
                    tasks.add(
                        CleaningTaskEntity(
                            id = obj.getString("id"),
                            areaId = obj.getString("areaId"),
                            name = obj.getString("name"),
                            instructions = obj.optString("instructions", null),
                            effortPoints = obj.optInt("effortPoints", 1),
                            estimatedMinutes = obj.optInt("estimatedMinutes", 30),
                            requiredPeople = obj.optInt("requiredPeople", 1),
                            isActive = obj.optBoolean("isActive", true),
                            recurrenceRule = obj.optString("recurrenceRule", "DAILY"),
                            createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                            updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                        )
                    )
                }
            }

            val assignments = mutableListOf<DailyAssignmentEntity>()
            val assignmentsArr = data.optJSONArray("assignments")
            if (assignmentsArr != null) {
                for (i in 0 until assignmentsArr.length()) {
                    val obj = assignmentsArr.getJSONObject(i)
                    assignments.add(
                        DailyAssignmentEntity(
                            id = obj.getString("id"),
                            planId = obj.getString("planId"),
                            taskId = obj.getString("taskId"),
                            personId = obj.getString("personId"),
                            assignmentDate = obj.getString("assignmentDate"),
                            effortPointsSnapshot = obj.optInt("effortPointsSnapshot", 1),
                            status = obj.optString("status", "PENDING"),
                            assignedAt = obj.optLong("assignedAt", System.currentTimeMillis()),
                            completedAt = if (obj.has("completedAt")) obj.optLong("completedAt") else null,
                            completionSource = obj.optString("completionSource", null),
                            notes = obj.optString("notes", null)
                        )
                    )
                }
            }

            // Insert restored entities into Room safely
            database.personDao().insertAll(people)
            database.areaDao().insertAll(areas)
            database.taskDao().insertAll(tasks)
            database.scheduleDao().insertAssignments(assignments)

            database.auditDao().insert(
                AuditLogEntity(
                    eventType = "RESTORE_DATABASE",
                    entityType = "BACKUP",
                    entityId = "JSON_RESTORE",
                    details = "تمت استعادة البيانات بنجاح: ${people.size} أفراد، ${areas.size} مناطق، ${tasks.size} مهام"
                )
            )

            Pair(true, "تمت استعادة البيانات بنجاح (${people.size} أفراد، ${areas.size} مناطق، ${tasks.size} مهام)")
        } catch (e: Exception) {
            Pair(false, "فشلت الاستعادة: ${e.message}")
        }
    }

    fun exportAssignmentsToCsv(
        assignments: List<DailyAssignmentEntity>,
        peopleById: Map<String, PersonEntity>,
        tasksById: Map<String, CleaningTaskEntity>
    ): String {
        val sb = StringBuilder()
        sb.append("التاريخ,رمز_التكليف,اسم_الفرد,رقم_الهاتف,المهمة,نقاط_الجهد,الحالة,ملاحظات\n")
        for (a in assignments) {
            val person = peopleById[a.personId]
            val task = tasksById[a.taskId]
            sb.append("\"${a.assignmentDate}\",")
            sb.append("\"${a.id.takeLast(6)}\",")
            sb.append("\"${person?.name ?: a.personId}\",")
            sb.append("\"${person?.phoneNumber ?: ""}\",")
            sb.append("\"${task?.name ?: a.taskId}\",")
            sb.append("${a.effortPointsSnapshot},")
            sb.append("\"${a.status}\",")
            sb.append("\"${a.notes ?: ""}\"\n")
        }
        return sb.toString()
    }
}
