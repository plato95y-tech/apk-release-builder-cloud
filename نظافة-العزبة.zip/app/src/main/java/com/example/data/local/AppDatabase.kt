package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.local.dao.AbsenceDao
import com.example.data.local.dao.AreaDao
import com.example.data.local.dao.AuditDao
import com.example.data.local.dao.PersonDao
import com.example.data.local.dao.ScheduleDao
import com.example.data.local.dao.SmsDao
import com.example.data.local.dao.TaskDao
import com.example.data.local.entity.AbsenceEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.CleaningAreaEntity
import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.DailyPlanEntity
import com.example.data.local.entity.PersonEntity
import com.example.data.local.entity.SmsAttemptEntity
import com.example.data.local.entity.SmsOutboxEntity

@Database(
    entities = [
        PersonEntity::class,
        CleaningAreaEntity::class,
        CleaningTaskEntity::class,
        DailyPlanEntity::class,
        DailyAssignmentEntity::class,
        AbsenceEntity::class,
        SmsOutboxEntity::class,
        SmsAttemptEntity::class,
        AuditLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun personDao(): PersonDao
    abstract fun areaDao(): AreaDao
    abstract fun taskDao(): TaskDao
    abstract fun scheduleDao(): ScheduleDao
    abstract fun absenceDao(): AbsenceDao
    abstract fun smsDao(): SmsDao
    abstract fun auditDao(): AuditDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "ezbah_cleaning.db"
                ).fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
