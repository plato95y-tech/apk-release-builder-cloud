package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import com.example.data.local.entity.AbsenceEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.CleaningAreaEntity
import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.DailyPlanEntity
import com.example.data.local.entity.PersonEntity
import com.example.data.local.entity.SmsAttemptEntity
import com.example.data.local.entity.SmsOutboxEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PersonDao {
    @Query("SELECT * FROM people ORDER BY name ASC")
    fun getAllFlow(): Flow<List<PersonEntity>>

    @Query("SELECT * FROM people ORDER BY name ASC")
    suspend fun getAllSync(): List<PersonEntity>

    @Query("SELECT * FROM people WHERE isActive = 1 ORDER BY name ASC")
    suspend fun getActiveSync(): List<PersonEntity>

    @Query("SELECT * FROM people WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): PersonEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(person: PersonEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(people: List<PersonEntity>)

    @Update
    suspend fun update(person: PersonEntity)

    @Delete
    suspend fun delete(person: PersonEntity)
}

@Dao
interface AreaDao {
    @Query("SELECT * FROM cleaning_areas ORDER BY name ASC")
    fun getAllFlow(): Flow<List<CleaningAreaEntity>>

    @Query("SELECT * FROM cleaning_areas ORDER BY name ASC")
    suspend fun getAllSync(): List<CleaningAreaEntity>

    @Query("SELECT * FROM cleaning_areas WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CleaningAreaEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(area: CleaningAreaEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(areas: List<CleaningAreaEntity>)

    @Update
    suspend fun update(area: CleaningAreaEntity)

    @Delete
    suspend fun delete(area: CleaningAreaEntity)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM cleaning_tasks ORDER BY name ASC")
    fun getAllFlow(): Flow<List<CleaningTaskEntity>>

    @Query("SELECT * FROM cleaning_tasks ORDER BY name ASC")
    suspend fun getAllSync(): List<CleaningTaskEntity>

    @Query("SELECT * FROM cleaning_tasks WHERE isActive = 1 ORDER BY name ASC")
    suspend fun getActiveSync(): List<CleaningTaskEntity>

    @Query("SELECT * FROM cleaning_tasks WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): CleaningTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(task: CleaningTaskEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(tasks: List<CleaningTaskEntity>)

    @Update
    suspend fun update(task: CleaningTaskEntity)

    @Delete
    suspend fun delete(task: CleaningTaskEntity)
}

@Dao
interface ScheduleDao {
    @Query("SELECT * FROM daily_plans WHERE planDate = :date ORDER BY version DESC LIMIT 1")
    fun getPlanForDateFlow(date: String): Flow<DailyPlanEntity?>

    @Query("SELECT * FROM daily_plans WHERE planDate = :date ORDER BY version DESC LIMIT 1")
    suspend fun getPlanForDateSync(date: String): DailyPlanEntity?

    @Query("SELECT * FROM daily_plans ORDER BY planDate DESC")
    fun getAllPlansFlow(): Flow<List<DailyPlanEntity>>

    @Query("SELECT * FROM daily_plans ORDER BY planDate DESC")
    suspend fun getAllPlansSync(): List<DailyPlanEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlan(plan: DailyPlanEntity)

    @Update
    suspend fun updatePlan(plan: DailyPlanEntity)

    @Query("SELECT * FROM daily_assignments WHERE planId = :planId")
    fun getAssignmentsForPlanFlow(planId: String): Flow<List<DailyAssignmentEntity>>

    @Query("SELECT * FROM daily_assignments WHERE planId = :planId")
    suspend fun getAssignmentsForPlanSync(planId: String): List<DailyAssignmentEntity>

    @Query("SELECT * FROM daily_assignments WHERE assignmentDate = :date")
    fun getAssignmentsForDateFlow(date: String): Flow<List<DailyAssignmentEntity>>

    @Query("SELECT * FROM daily_assignments WHERE assignmentDate = :date")
    suspend fun getAssignmentsForDateSync(date: String): List<DailyAssignmentEntity>

    @Query("SELECT * FROM daily_assignments WHERE assignmentDate BETWEEN :startDate AND :endDate")
    suspend fun getAssignmentsInRangeSync(startDate: String, endDate: String): List<DailyAssignmentEntity>

    @Query("SELECT * FROM daily_assignments ORDER BY assignmentDate DESC")
    fun getAllAssignmentsFlow(): Flow<List<DailyAssignmentEntity>>

    @Query("SELECT * FROM daily_assignments ORDER BY assignmentDate DESC")
    suspend fun getAllAssignmentsSync(): List<DailyAssignmentEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignments(assignments: List<DailyAssignmentEntity>)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAssignment(assignment: DailyAssignmentEntity)

    @Update
    suspend fun updateAssignment(assignment: DailyAssignmentEntity)

    @Query("DELETE FROM daily_assignments WHERE planId = :planId")
    suspend fun deleteAssignmentsForPlan(planId: String)

    @Transaction
    suspend fun replacePlanWithAssignments(plan: DailyPlanEntity, assignments: List<DailyAssignmentEntity>) {
        insertPlan(plan)
        deleteAssignmentsForPlan(plan.id)
        insertAssignments(assignments)
    }
}

@Dao
interface AbsenceDao {
    @Query("SELECT * FROM absences ORDER BY startDate DESC")
    fun getAllFlow(): Flow<List<AbsenceEntity>>

    @Query("SELECT * FROM absences ORDER BY startDate DESC")
    suspend fun getAllSync(): List<AbsenceEntity>

    @Query("SELECT * FROM absences WHERE :date BETWEEN startDate AND endDate")
    suspend fun getAbsencesForDate(date: String): List<AbsenceEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(absence: AbsenceEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(absences: List<AbsenceEntity>)

    @Delete
    suspend fun delete(absence: AbsenceEntity)
}

@Dao
interface SmsDao {
    @Query("SELECT * FROM sms_outbox ORDER BY createdAt DESC")
    fun getAllOutboxFlow(): Flow<List<SmsOutboxEntity>>

    @Query("SELECT * FROM sms_outbox ORDER BY createdAt DESC")
    suspend fun getAllOutboxSync(): List<SmsOutboxEntity>

    @Query("SELECT * FROM sms_outbox WHERE status = :status ORDER BY createdAt DESC")
    fun getOutboxByStatusFlow(status: String): Flow<List<SmsOutboxEntity>>

    @Query("SELECT * FROM sms_outbox WHERE status IN ('QUEUED', 'RETRY_WAIT') ORDER BY createdAt ASC")
    suspend fun getPendingOutboxSync(): List<SmsOutboxEntity>

    @Query("SELECT * FROM sms_outbox WHERE id = :id LIMIT 1")
    suspend fun getById(id: String): SmsOutboxEntity?

    @Query("SELECT * FROM sms_outbox WHERE idempotencyKey = :key LIMIT 1")
    suspend fun getByIdempotencyKey(key: String): SmsOutboxEntity?

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessage(message: SmsOutboxEntity): Long

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertMessages(messages: List<SmsOutboxEntity>): List<Long>

    @Update
    suspend fun updateMessage(message: SmsOutboxEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttempt(attempt: SmsAttemptEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAttempts(attempts: List<SmsAttemptEntity>)

    @Query("SELECT * FROM sms_attempts WHERE messageId = :messageId ORDER BY attemptNumber ASC")
    suspend fun getAttemptsForMessage(messageId: String): List<SmsAttemptEntity>

    @Query("SELECT * FROM sms_attempts ORDER BY startedAt DESC")
    fun getAllAttemptsFlow(): Flow<List<SmsAttemptEntity>>

    @Query("SELECT * FROM sms_attempts ORDER BY startedAt DESC")
    suspend fun getAllAttemptsSync(): List<SmsAttemptEntity>
}

@Dao
interface AuditDao {
    @Query("SELECT * FROM audit_logs ORDER BY createdAt DESC LIMIT 100")
    fun getAllFlow(): Flow<List<AuditLogEntity>>

    @Query("SELECT * FROM audit_logs ORDER BY createdAt DESC")
    suspend fun getAllSync(): List<AuditLogEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: AuditLogEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(logs: List<AuditLogEntity>)
}
