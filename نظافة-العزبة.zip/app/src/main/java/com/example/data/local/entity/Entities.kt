package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey
import java.util.UUID

@Entity(tableName = "people")
data class PersonEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val phoneNumber: String,
    val isActive: Boolean = true,
    val notes: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "cleaning_areas")
data class CleaningAreaEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String? = null,
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "cleaning_tasks",
    indices = [Index(value = ["areaId"])]
)
data class CleaningTaskEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val areaId: String,
    val name: String,
    val instructions: String? = null,
    val effortPoints: Int = 1, // 1 (light), 2 (medium), 3 (heavy)
    val estimatedMinutes: Int? = 30,
    val requiredPeople: Int = 1,
    val isActive: Boolean = true,
    val recurrenceRule: String? = "DAILY",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "daily_plans",
    indices = [Index(value = ["planDate", "version"], unique = true)]
)
data class DailyPlanEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val planDate: String, // YYYY-MM-DD
    val status: String = "DRAFT", // DRAFT, APPROVED
    val version: Int = 1,
    val createdAt: Long = System.currentTimeMillis(),
    val approvedAt: Long? = null,
    val notes: String? = null
)

@Entity(
    tableName = "daily_assignments",
    indices = [
        Index(value = ["planId"]),
        Index(value = ["taskId"]),
        Index(value = ["personId"]),
        Index(value = ["assignmentDate"])
    ]
)
data class DailyAssignmentEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val planId: String,
    val taskId: String,
    val personId: String,
    val assignmentDate: String, // YYYY-MM-DD
    val effortPointsSnapshot: Int,
    val status: String = "PENDING", // PENDING, COMPLETED, OVERDUE, EXCUSED, CANCELLED, REASSIGNED
    val assignedAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val completionSource: String? = null,
    val notes: String? = null
)

@Entity(
    tableName = "absences",
    indices = [Index(value = ["personId"])]
)
data class AbsenceEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val personId: String,
    val startDate: String, // YYYY-MM-DD
    val endDate: String, // YYYY-MM-DD
    val reason: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(
    tableName = "sms_outbox",
    indices = [
        Index(value = ["idempotencyKey"], unique = true),
        Index(value = ["personId"]),
        Index(value = ["status"])
    ]
)
data class SmsOutboxEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val assignmentId: String? = null,
    val personId: String,
    val recipientPhoneSnapshot: String,
    val bodySnapshot: String,
    val status: String = "QUEUED", // QUEUED, SENDING, SENT, DELIVERED, RETRY_WAIT, FAILED, UNKNOWN, CANCELLED
    val attemptCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val nextAttemptAt: Long? = null,
    val sentAt: Long? = null,
    val deliveredAt: Long? = null,
    val lastErrorCode: String? = null,
    val lastErrorMessage: String? = null,
    val idempotencyKey: String
)

@Entity(
    tableName = "sms_attempts",
    indices = [Index(value = ["messageId"])]
)
data class SmsAttemptEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val messageId: String,
    val attemptNumber: Int,
    val startedAt: Long = System.currentTimeMillis(),
    val finishedAt: Long? = null,
    val result: String, // SUCCESS, GENERIC_FAILURE, NO_SERVICE, NULL_PDU, RADIO_OFF, UNKNOWN
    val platformResultCode: Int? = null,
    val errorSummary: String? = null
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String = UUID.randomUUID().toString(),
    val eventType: String,
    val entityType: String,
    val entityId: String,
    val details: String,
    val createdAt: Long = System.currentTimeMillis()
)
