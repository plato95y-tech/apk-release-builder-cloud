package com.example.data.preferences

import android.content.Context
import android.content.SharedPreferences

class AppPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("ezbah_settings", Context.MODE_PRIVATE)

    var defaultDueTime: String
        get() = prefs.getString("default_due_time", "اليوم بعد العصر") ?: "اليوم بعد العصر"
        set(value) = prefs.edit().putString("default_due_time", value).apply()

    var maxDailyTasksPerPerson: Int
        get() = prefs.getInt("max_daily_tasks", 2)
        set(value) = prefs.edit().putInt("max_daily_tasks", value).apply()

    var maxDailyEffortPoints: Int
        get() = prefs.getInt("max_daily_effort", 4)
        set(value) = prefs.edit().putInt("max_daily_effort", value).apply()

    var maxSmsRetryCount: Int
        get() = prefs.getInt("max_sms_retry", 4)
        set(value) = prefs.edit().putInt("max_sms_retry", value).apply()

    var assignmentTemplate: String
        get() = prefs.getString(
            "assignment_template",
            """
                السلام عليكم {اسم_الفرد}

                تكليف النظافة اليوم: {اسم_المهمة}
                المكان: {اسم_المنطقة}
                الموعد: {الموعد}
                رقم التكليف: {رمز_التكليف}

                عند الانتهاء، أبلغ المسؤول.
            """.trimIndent()
        ) ?: ""
        set(value) = prefs.edit().putString("assignment_template", value).apply()

    var reminderTemplate: String
        get() = prefs.getString(
            "reminder_template",
            """
                تذكير: المهمة «{اسم_المهمة}» ما زالت مسجلة غير مكتملة.
                إذا أنجزتها، أبلغ المسؤول. وإذا تعذر عليك تنفيذها، تواصل مع المسؤول لترتيب البديل.
                رقم التكليف: {رمز_التكليف}
            """.trimIndent()
        ) ?: ""
        set(value) = prefs.edit().putString("reminder_template", value).apply()
}
