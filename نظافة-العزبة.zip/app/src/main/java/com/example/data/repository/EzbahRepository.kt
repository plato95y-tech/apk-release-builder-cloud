package com.example.data.repository

import com.example.data.local.AppDatabase
import com.example.data.local.entity.AbsenceEntity
import com.example.data.local.entity.AuditLogEntity
import com.example.data.local.entity.CleaningAreaEntity
import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.DailyPlanEntity
import com.example.data.local.entity.PersonEntity
import com.example.data.local.entity.SmsAttemptEntity
import com.example.data.local.entity.SmsOutboxEntity
import com.example.domain.scheduler.FairScheduler
import com.example.platform.sms.SmsManagerHelper
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class EzbahRepository(private val database: AppDatabase) {

    val peopleFlow: Flow<List<PersonEntity>> = database.personDao().getAllFlow()
    val areasFlow: Flow<List<CleaningAreaEntity>> = database.areaDao().getAllFlow()
    val tasksFlow: Flow<List<CleaningTaskEntity>> = database.taskDao().getAllFlow()
    val absencesFlow: Flow<List<AbsenceEntity>> = database.absenceDao().getAllFlow()
    val outboxFlow: Flow<List<SmsOutboxEntity>> = database.smsDao().getAllOutboxFlow()
    val allAssignmentsFlow: Flow<List<DailyAssignmentEntity>> = database.scheduleDao().getAllAssignmentsFlow()
    val auditLogsFlow: Flow<List<AuditLogEntity>> = database.auditDao().getAllFlow()

    fun getAssignmentsForDateFlow(date: String): Flow<List<DailyAssignmentEntity>> =
        database.scheduleDao().getAssignmentsForDateFlow(date)

    fun getPlanForDateFlow(date: String): Flow<DailyPlanEntity?> =
        database.scheduleDao().getPlanForDateFlow(date)

    suspend fun getActivePeople(): List<PersonEntity> = database.personDao().getActiveSync()
    suspend fun getAllPeople(): List<PersonEntity> = database.personDao().getAllSync()
    suspend fun getAllAreas(): List<CleaningAreaEntity> = database.areaDao().getAllSync()
    suspend fun getActiveTasks(): List<CleaningTaskEntity> = database.taskDao().getActiveSync()
    suspend fun getAllTasks(): List<CleaningTaskEntity> = database.taskDao().getAllSync()

    suspend fun getAbsencesForDate(date: String): List<AbsenceEntity> =
        database.absenceDao().getAbsencesForDate(date)

    suspend fun getPast14DaysAssignments(date: String): List<DailyAssignmentEntity> {
        val startDate = FairScheduler.get14DaysAgoDate(date)
        return database.scheduleDao().getAssignmentsInRangeSync(startDate, date)
    }

    suspend fun savePerson(person: PersonEntity) {
        database.personDao().insert(person)
        logAudit("SAVE_PERSON", "PERSON", person.id, "تم حفظ بيانات الفرد: ${person.name}")
    }

    suspend fun deletePerson(person: PersonEntity) {
        // Soft delete / deactivate is preferred, but delete is supported if unassigned
        database.personDao().delete(person)
        logAudit("DELETE_PERSON", "PERSON", person.id, "تم حذف الفرد: ${person.name}")
    }

    suspend fun saveArea(area: CleaningAreaEntity) {
        database.areaDao().insert(area)
        logAudit("SAVE_AREA", "AREA", area.id, "تم حفظ المنطقة: ${area.name}")
    }

    suspend fun deleteArea(area: CleaningAreaEntity) {
        database.areaDao().delete(area)
        logAudit("DELETE_AREA", "AREA", area.id, "تم حذف المنطقة: ${area.name}")
    }

    suspend fun saveTask(task: CleaningTaskEntity) {
        database.taskDao().insert(task)
        logAudit("SAVE_TASK", "TASK", task.id, "تم حفظ المهمة: ${task.name} (${task.effortPoints} نقاط)")
    }

    suspend fun deleteTask(task: CleaningTaskEntity) {
        database.taskDao().delete(task)
        logAudit("DELETE_TASK", "TASK", task.id, "تم حذف المهمة: ${task.name}")
    }

    suspend fun saveAbsence(absence: AbsenceEntity) {
        database.absenceDao().insert(absence)
        val person = database.personDao().getById(absence.personId)
        logAudit(
            "SAVE_ABSENCE",
            "ABSENCE",
            absence.id,
            "تسجيل غياب للفرد ${person?.name ?: absence.personId} من ${absence.startDate} إلى ${absence.endDate}"
        )
    }

    suspend fun deleteAbsence(absence: AbsenceEntity) {
        database.absenceDao().delete(absence)
    }

    suspend fun approvePlanAndAssignments(
        plan: DailyPlanEntity,
        assignments: List<DailyAssignmentEntity>
    ) {
        val approvedPlan = plan.copy(
            status = "APPROVED",
            approvedAt = System.currentTimeMillis()
        )
        database.scheduleDao().replacePlanWithAssignments(approvedPlan, assignments)
        logAudit(
            "APPROVE_PLAN",
            "DAILY_PLAN",
            approvedPlan.id,
            "تم اعتماد جدول تاريخ ${approvedPlan.planDate} متضمناً ${assignments.size} تكليفاً"
        )
    }

    suspend fun checkAndCleanStaleSendingMessages() {
        val allOutbox = database.smsDao().getAllOutboxSync()
        val staleSending = allOutbox.filter {
            it.status == "SENDING" && (System.currentTimeMillis() - it.createdAt > 300_000L)
        }
        for (stale in staleSending) {
            database.smsDao().updateMessage(
                stale.copy(
                    status = "UNKNOWN",
                    lastErrorMessage = "توقفت الرسالة بحالة الإرسال أثناء إغلاق التطبيق، تم تحويلها للمراجعة اليدوية."
                )
            )
            logAudit(
                "STALE_SMS_TO_UNKNOWN",
                "SMS_OUTBOX",
                stale.id,
                "تم تحويل الرسالة إلى UNKNOWN لعدم حسم نتيجتها بعد إعادة التشغيل"
            )
        }
    }

    suspend fun prepareSmsOutboxForPlan(
        planId: String,
        date: String,
        dueTime: String = "اليوم بعد العصر"
    ): Int {
        val assignments = database.scheduleDao().getAssignmentsForPlanSync(planId)
        val people = database.personDao().getAllSync().associateBy { it.id }
        val tasks = database.taskDao().getAllSync().associateBy { it.id }
        val areas = database.areaDao().getAllSync().associateBy { it.id }

        val messages = mutableListOf<SmsOutboxEntity>()

        for (asg in assignments) {
            val person = people[asg.personId] ?: continue
            val task = tasks[asg.taskId]
            val area = task?.let { areas[it.areaId] }

            val taskName = task?.name ?: "مهمة نظافة"
            val areaName = area?.name ?: "موقع العزبة"
            val body = SmsManagerHelper.formatAssignmentMessage(
                personName = person.name,
                taskName = taskName,
                areaName = areaName,
                dueTime = dueTime,
                assignmentCode = asg.id
            )

            // Idempotency key prevents logical duplicates: planId:assignmentId:v1
            val idempotencyKey = "${planId}:${asg.id}:ASSIGNMENT:v1"

            messages.add(
                SmsOutboxEntity(
                    id = UUID.randomUUID().toString(),
                    assignmentId = asg.id,
                    personId = person.id,
                    recipientPhoneSnapshot = person.phoneNumber,
                    bodySnapshot = body,
                    status = "QUEUED",
                    idempotencyKey = idempotencyKey
                )
            )
        }

        database.smsDao().insertMessages(messages)
        logAudit(
            "PREPARE_SMS",
            "SMS_OUTBOX",
            planId,
            "تم تجهيز ${messages.size} رسالة في صندوق الانتظار لجدول $date"
        )
        return messages.size
    }

    suspend fun reassignAssignment(
        oldAssignmentId: String,
        newPersonId: String,
        reason: String
    ) {
        val assignments = database.scheduleDao().getAllAssignmentsSync()
        val old = assignments.firstOrNull { it.id == oldAssignmentId } ?: return
        val newPerson = database.personDao().getById(newPersonId) ?: return

        // Mark old as REASSIGNED
        database.scheduleDao().updateAssignment(
            old.copy(
                status = "REASSIGNED",
                notes = "أعيد تعيينها إلى ${newPerson.name}. السبب: $reason"
            )
        )

        // Create new assignment
        val newAssignment = DailyAssignmentEntity(
            id = UUID.randomUUID().toString(),
            planId = old.planId,
            taskId = old.taskId,
            personId = newPerson.id,
            assignmentDate = old.assignmentDate,
            effortPointsSnapshot = old.effortPointsSnapshot,
            status = "PENDING",
            assignedAt = System.currentTimeMillis(),
            notes = "بديل لـ ${database.personDao().getById(old.personId)?.name ?: old.personId}. السبب: $reason"
        )
        database.scheduleDao().insertAssignment(newAssignment)

        logAudit(
            "REASSIGN_TASK",
            "DAILY_ASSIGNMENT",
            newAssignment.id,
            "إعادة تعيين المهمة من الفرد القديم إلى ${newPerson.name} بسبب: $reason"
        )
    }

    suspend fun recordSmsAttempt(
        messageId: String,
        result: String,
        errorSummary: String? = null
    ) {
        val msg = database.smsDao().getById(messageId) ?: return
        val newAttemptCount = msg.attemptCount + 1

        val newStatus = when (result) {
            "SUCCESS" -> "SENT"
            "UNKNOWN" -> "UNKNOWN"
            else -> if (newAttemptCount >= 4) "FAILED" else "RETRY_WAIT"
        }

        val updatedMsg = msg.copy(
            status = newStatus,
            attemptCount = newAttemptCount,
            sentAt = if (result == "SUCCESS") System.currentTimeMillis() else msg.sentAt,
            lastErrorCode = if (result != "SUCCESS") result else null,
            lastErrorMessage = errorSummary
        )
        database.smsDao().updateMessage(updatedMsg)

        database.smsDao().insertAttempt(
            SmsAttemptEntity(
                messageId = messageId,
                attemptNumber = newAttemptCount,
                finishedAt = System.currentTimeMillis(),
                result = result,
                errorSummary = errorSummary
            )
        )
    }

    suspend fun updateMessageStatus(messageId: String, status: String) {
        val msg = database.smsDao().getById(messageId) ?: return
        database.smsDao().updateMessage(msg.copy(status = status))
    }

    suspend fun updateAssignmentStatus(assignmentId: String, newStatus: String, notes: String? = null) {
        val assignments = database.scheduleDao().getAllAssignmentsSync()
        val asg = assignments.firstOrNull { it.id == assignmentId } ?: return
        val updated = asg.copy(
            status = newStatus,
            completedAt = if (newStatus == "COMPLETED") System.currentTimeMillis() else asg.completedAt,
            notes = if (notes != null) notes else asg.notes,
            completionSource = "MANUAL_ADMIN"
        )
        database.scheduleDao().updateAssignment(updated)
        logAudit("UPDATE_ASSIGNMENT", "DAILY_ASSIGNMENT", assignmentId, "تحديث حالة التكليف إلى: $newStatus")
    }

    suspend fun logAudit(eventType: String, entityType: String, entityId: String, details: String) {
        database.auditDao().insert(
            AuditLogEntity(
                eventType = eventType,
                entityType = entityType,
                entityId = entityId,
                details = details
            )
        )
    }

    /**
     * Seeds initial sample data for Ezbah if the database is newly initialized.
     */
    suspend fun seedInitialDataIfEmpty() {
        if (database.personDao().getAllSync().isNotEmpty()) return

        val people = listOf(
            PersonEntity(name = "محمد القحطاني", phoneNumber = "0501234567"),
            PersonEntity(name = "عبدالله الدوسري", phoneNumber = "0559876543"),
            PersonEntity(name = "خالد العتيبي", phoneNumber = "0531122334"),
            PersonEntity(name = "فهد المطيري", phoneNumber = "0545566778"),
            PersonEntity(name = "عبدالرحمن الشمري", phoneNumber = "0569988776"),
            PersonEntity(name = "سلطان الحربي", phoneNumber = "0507744112"),
            PersonEntity(name = "سعد الغامدي", phoneNumber = "0553322110"),
            PersonEntity(name = "عبدالعزيز السبيعي", phoneNumber = "0534455667"),
            PersonEntity(name = "ناصر التميمي", phoneNumber = "0548899001"),
            PersonEntity(name = "راشد الشهري", phoneNumber = "0561239874")
        )
        database.personDao().insertAll(people)

        val area1 = CleaningAreaEntity(name = "المجلس الرئيسي", description = "صالة الجلسة الرئيسية ومكان الضيافة")
        val area2 = CleaningAreaEntity(name = "المطبخ والمستودع", description = "أدوات الطهي، الثلاجات، والأواني")
        val area3 = CleaningAreaEntity(name = "دورات المياه والمغاسل", description = "النظافة العامة والتعقيم")
        val area4 = CleaningAreaEntity(name = "الفناء الخارجي والشواية", description = "الحوش، كنس الأرضية ومكان الشواء")
        database.areaDao().insertAll(listOf(area1, area2, area3, area4))

        val tasks = listOf(
            CleaningTaskEntity(
                areaId = area1.id,
                name = "كنس وترتيب المجلس الرئيسي",
                effortPoints = 1, // خفيف
                estimatedMinutes = 25,
                requiredPeople = 1,
                instructions = "ترتيب المساند وكنس السجاد وتبخير المجلس"
            ),
            CleaningTaskEntity(
                areaId = area2.id,
                name = "غسيل أواني المطبخ وتنظيف الأسطح",
                effortPoints = 2, // متوسط
                estimatedMinutes = 40,
                requiredPeople = 1,
                instructions = "غسيل الصحون ومسح رخام المطبخ وإخراج كيس النفايات"
            ),
            CleaningTaskEntity(
                areaId = area3.id,
                name = "غسيل وتعقيم دورات المياه",
                effortPoints = 3, // شاق
                estimatedMinutes = 45,
                requiredPeople = 1,
                instructions = "تنظيف المغاسل، تعقيم الحمام بالكلور، وتبديل أكياس القمامة"
            ),
            CleaningTaskEntity(
                areaId = area4.id,
                name = "تنظيف الشواية وكنس الحوش",
                effortPoints = 2, // متوسط
                estimatedMinutes = 35,
                requiredPeople = 1,
                instructions = "إزالة الفحم الزائد وكنس ممر الحوش"
            ),
            CleaningTaskEntity(
                areaId = area2.id,
                name = "جرد الثلاجة ومسح الرفوف",
                effortPoints = 1, // خفيف
                estimatedMinutes = 20,
                requiredPeople = 1,
                instructions = "ترتيب الأطعمة وتفقد الأغراض منتهية الصلاحية"
            )
        )
        database.taskDao().insertAll(tasks)

        logAudit("INITIAL_SEED", "SYSTEM", "INIT", "تمت تهيئة بيانات العزبة الافتراضية بنجاح.")
    }
}
