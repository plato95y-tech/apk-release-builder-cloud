package com.example.domain.model

enum class PlanStatus {
    DRAFT,
    APPROVED
}

enum class AssignmentStatus(val labelAr: String) {
    PENDING("قيد الانتظار"),
    COMPLETED("تم الإنجاز"),
    OVERDUE("متأخر"),
    EXCUSED("معذور"),
    CANCELLED("ملغي"),
    REASSIGNED("معاد التعيين")
}

enum class SmsStatus(val labelAr: String) {
    QUEUED("في الانتظار"),
    SENDING("جاري الإرسال"),
    SENT("تم الإرسال للشبكة"),
    DELIVERED("تم التسليم"),
    RETRY_WAIT("بانتظار إعادة المحاولة"),
    FAILED("فشل الإرسال"),
    UNKNOWN("غير محسوم (للمراجعة)"),
    CANCELLED("ملغية")
}

enum class TaskEffort(val points: Int, val labelAr: String) {
    LIGHT(1, "خفيف (نقطة واحدة)"),
    MEDIUM(2, "متوسط (نقطتان)"),
    HEAVY(3, "شاق (3 نقاط)");

    companion object {
        fun fromPoints(points: Int): TaskEffort = when (points) {
            1 -> LIGHT
            2 -> MEDIUM
            else -> HEAVY
        }
    }
}
