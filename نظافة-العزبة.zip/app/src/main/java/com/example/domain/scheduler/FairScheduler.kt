package com.example.domain.scheduler

import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.PersonEntity
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.UUID

data class ProposedAssignment(
    val id: String = UUID.randomUUID().toString(),
    val taskId: String,
    val taskName: String,
    val areaName: String,
    val personId: String,
    val personName: String,
    val effortPoints: Int,
    val reasonNote: String = ""
)

data class UncoveredTask(
    val taskId: String,
    val taskName: String,
    val areaName: String,
    val requiredPeople: Int,
    val availableCount: Int,
    val reason: String
)

data class PersonLoad(
    val personId: String,
    val personName: String,
    var effortLast14Days: Int,
    var tasksLast14Days: Int,
    var assignedTodayEffort: Int = 0,
    var assignedTodayTasks: Int = 0
)

data class FairnessSummary(
    val totalTasks: Int,
    val totalEffort: Int,
    val availablePeopleCount: Int,
    val minEffortPerson: String,
    val maxEffortPerson: String,
    val effortVariance: Double,
    val loads: List<PersonLoad>
)

data class ScheduleProposal(
    val date: String,
    val proposedAssignments: List<ProposedAssignment>,
    val uncoveredTasks: List<UncoveredTask>,
    val warnings: List<String>,
    val fairnessSummary: FairnessSummary
)

object FairScheduler {

    fun generateProposal(
        date: String,
        activePeople: List<PersonEntity>,
        absentPersonIds: Set<String>,
        tasks: List<CleaningTaskEntity>,
        areaNamesById: Map<String, String>,
        past14DaysAssignments: List<DailyAssignmentEntity>,
        yesterdayDate: String,
        maxDailyTasks: Int = 2,
        maxDailyEffort: Int = 4
    ): ScheduleProposal {
        val warnings = mutableListOf<String>()
        val uncovered = mutableListOf<UncoveredTask>()
        val proposed = mutableListOf<ProposedAssignment>()

        // 1. Filter eligible candidates (Hard constraint 1: must be active and not absent)
        val availablePeople = activePeople.filter { it.isActive && it.id !in absentPersonIds }

        if (availablePeople.isEmpty()) {
            return ScheduleProposal(
                date = date,
                proposedAssignments = emptyList(),
                uncoveredTasks = tasks.map {
                    UncoveredTask(
                        taskId = it.id,
                        taskName = it.name,
                        areaName = areaNamesById[it.areaId] ?: "المنطقة",
                        requiredPeople = it.requiredPeople,
                        availableCount = 0,
                        reason = "لا يوجد أي فرد متاح في هذا التاريخ بسبب الغياب أو عدم التفعيل."
                    )
                },
                warnings = listOf("تحذير حرج: لا يوجد أي فرد متاح في تاريخ $date!"),
                fairnessSummary = FairnessSummary(0, 0, 0, "-", "-", 0.0, emptyList())
            )
        }

        // 2. Build 14-day history metrics per person
        val loadMap = availablePeople.associate { person ->
            val personHistory = past14DaysAssignments.filter { it.personId == person.id }
            val effort = personHistory.sumOf { it.effortPointsSnapshot }
            val count = personHistory.size
            person.id to PersonLoad(
                personId = person.id,
                personName = person.name,
                effortLast14Days = effort,
                tasksLast14Days = count
            )
        }.toMutableMap()

        // Yesterday tasks mapping to penalize consecutive identical task
        val yesterdayTasksByPerson = past14DaysAssignments
            .filter { it.assignmentDate == yesterdayDate }
            .groupBy({ it.personId }, { it.taskId })

        // 3. Sort tasks by constraint count & effort:
        // - Required people descending
        // - Effort points descending
        val sortedTasks = tasks.sortedWith(
            compareByDescending<CleaningTaskEntity> { it.requiredPeople }
                .thenByDescending { it.effortPoints }
        )

        // 4. Assign each task with hard limit check
        for (task in sortedTasks) {
            val req = task.requiredPeople.coerceAtLeast(1)
            val areaName = areaNamesById[task.areaId] ?: "منطقة عامة"

            // Filter candidates that meet hard daily limits first
            val eligibleCandidates = availablePeople.filter { p ->
                val load = loadMap[p.id]!!
                load.assignedTodayTasks < maxDailyTasks && (load.assignedTodayEffort + task.effortPoints) <= maxDailyEffort
            }

            // Fallback to all available candidates if limits prevent covering essential task
            val pool = if (eligibleCandidates.size >= req) eligibleCandidates else availablePeople

            val candidates = pool.sortedWith(
                compareBy<PersonEntity> { p ->
                    val load = loadMap[p.id]!!
                    val currentTotalEffort = load.effortLast14Days + load.assignedTodayEffort
                    val todayPenalty = load.assignedTodayTasks * 10
                    val consecutivePenalty = if (yesterdayTasksByPerson[p.id]?.contains(task.id) == true) 15 else 0
                    val heavyPenalty = if (task.effortPoints >= 3 && load.assignedTodayEffort >= 2) 20 else 0

                    currentTotalEffort * 5 + load.tasksLast14Days * 2 + todayPenalty + consecutivePenalty + heavyPenalty
                }
            )

            if (candidates.size < req) {
                uncovered.add(
                    UncoveredTask(
                        taskId = task.id,
                        taskName = task.name,
                        areaName = areaName,
                        requiredPeople = req,
                        availableCount = candidates.size,
                        reason = "الأفراد المتاحون (${candidates.size}) أقل من العدد المطلوب للمهمة ($req)"
                    )
                )
                warnings.add("المهمة «${task.name}» لم تُغطَّ بالكامل لنقص الأفراد المتاحين.")
                continue
            }

            val chosenCandidates = candidates.take(req)
            for (chosen in chosenCandidates) {
                val load = loadMap[chosen.id]!!
                load.assignedTodayEffort += task.effortPoints
                load.assignedTodayTasks += 1

                val isConsecutive = yesterdayTasksByPerson[chosen.id]?.contains(task.id) == true
                if (isConsecutive) {
                    warnings.add("تنبيه تكرار: «${chosen.name}» كُلّف بالمهمة «${task.name}» بالأمس أيضاً لعدم توفر بديل أنسب.")
                }

                proposed.add(
                    ProposedAssignment(
                        taskId = task.id,
                        taskName = task.name,
                        areaName = areaName,
                        personId = chosen.id,
                        personName = chosen.name,
                        effortPoints = task.effortPoints,
                        reasonNote = if (isConsecutive) "تكرار قريب لعدم توفر بديل" else "توزيع عادل متوازن"
                    )
                )
            }
        }

        // 5. Local 2-opt Swap Optimization Step (Section 8: improve assignments with valid swaps)
        if (proposed.size >= 2) {
            for (i in 0 until proposed.size) {
                for (j in i + 1 until proposed.size) {
                    val a1 = proposed[i]
                    val a2 = proposed[j]
                    if (a1.personId != a2.personId && a1.effortPoints != a2.effortPoints) {
                        val p1Load = loadMap[a1.personId]!!
                        val p2Load = loadMap[a2.personId]!!

                        val currentVariance = Math.abs(
                            (p1Load.effortLast14Days + p1Load.assignedTodayEffort) -
                                    (p2Load.effortLast14Days + p2Load.assignedTodayEffort)
                        )

                        // Test swap
                        val newP1Today = p1Load.assignedTodayEffort - a1.effortPoints + a2.effortPoints
                        val newP2Today = p2Load.assignedTodayEffort - a2.effortPoints + a1.effortPoints

                        val newVariance = Math.abs(
                            (p1Load.effortLast14Days + newP1Today) -
                                    (p2Load.effortLast14Days + newP2Today)
                        )

                        if (newVariance < currentVariance && newP1Today <= maxDailyEffort + 1 && newP2Today <= maxDailyEffort + 1) {
                            // Apply swap
                            p1Load.assignedTodayEffort = newP1Today
                            p2Load.assignedTodayEffort = newP2Today

                            proposed[i] = a1.copy(personId = a2.personId, personName = a2.personName)
                            proposed[j] = a2.copy(personId = a1.personId, personName = a1.personName)
                        }
                    }
                }
            }
        }

        // 6. Final Fairness Summary Calculation
        val loadsList = loadMap.values.toList()
        val totalEffort = proposed.sumOf { it.effortPoints }
        val sortedByTotalEffort = loadsList.sortedBy { it.effortLast14Days + it.assignedTodayEffort }
        val minPerson = sortedByTotalEffort.firstOrNull()?.let { "${it.personName} (${it.effortLast14Days + it.assignedTodayEffort} نقطة)" } ?: "-"
        val maxPerson = sortedByTotalEffort.lastOrNull()?.let { "${it.personName} (${it.effortLast14Days + it.assignedTodayEffort} نقطة)" } ?: "-"

        val efforts = loadsList.map { (it.effortLast14Days + it.assignedTodayEffort).toDouble() }
        val avg = if (efforts.isNotEmpty()) efforts.average() else 0.0
        val variance = if (efforts.isNotEmpty()) efforts.sumOf { (it - avg) * (it - avg) } / efforts.size else 0.0

        val fairnessSummary = FairnessSummary(
            totalTasks = proposed.size,
            totalEffort = totalEffort,
            availablePeopleCount = availablePeople.size,
            minEffortPerson = minPerson,
            maxEffortPerson = maxPerson,
            effortVariance = String.format(Locale.US, "%.2f", variance).toDoubleOrNull() ?: 0.0,
            loads = loadsList
        )

        return ScheduleProposal(
            date = date,
            proposedAssignments = proposed,
            uncoveredTasks = uncovered,
            warnings = warnings,
            fairnessSummary = fairnessSummary
        )
    }

    fun getYesterdayDate(dateStr: String): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(dateStr) ?: return dateStr
            val cal = Calendar.getInstance().apply {
                time = date
                add(Calendar.DAY_OF_YEAR, -1)
            }
            sdf.format(cal.time)
        } catch (_: Exception) {
            dateStr
        }
    }

    fun getTodayDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        return sdf.format(Calendar.getInstance().time)
    }

    fun get14DaysAgoDate(dateStr: String): String {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val date = sdf.parse(dateStr) ?: return dateStr
            val cal = Calendar.getInstance().apply {
                time = date
                add(Calendar.DAY_OF_YEAR, -14)
            }
            sdf.format(cal.time)
        } catch (_: Exception) {
            dateStr
        }
    }
}
