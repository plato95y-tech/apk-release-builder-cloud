package com.example.platform.sms

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import androidx.core.content.ContextCompat

object SmsManagerHelper {

    fun formatAssignmentMessage(
        personName: String,
        taskName: String,
        areaName: String,
        dueTime: String = "اليوم بعد العصر",
        assignmentCode: String
    ): String {
        return """
            السلام عليكم $personName

            تكليف النظافة اليوم: $taskName
            المكان: $areaName
            الموعد: $dueTime
            رقم التكليف: ${assignmentCode.takeLast(6).uppercase()}

            عند الانتهاء، أبلغ المسؤول.
        """.trimIndent()
    }

    fun formatReminderMessage(
        taskName: String,
        assignmentCode: String
    ): String {
        return """
            تذكير: المهمة «$taskName» ما زالت مسجلة غير مكتملة.
            إذا أنجزتها، أبلغ المسؤول. وإذا تعذر عليك تنفيذها، تواصل مع المسؤول لترتيب البديل.
            رقم التكليف: ${assignmentCode.takeLast(6).uppercase()}
        """.trimIndent()
    }

    fun hasSmsPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun sendDirectSms(
        context: Context,
        phoneNumber: String,
        message: String,
        sentIntent: PendingIntent? = null
    ): Pair<Boolean, String?> {
        val cleanPhone = phoneNumber.trim().replace(" ", "")
        if (cleanPhone.isEmpty()) {
            return Pair(false, "رقم الهاتف فارغ")
        }

        if (!hasSmsPermission(context)) {
            return Pair(false, "إذن إرسال الرسائل (SEND_SMS) غير ممنوح")
        }

        return try {
            val smsManager: SmsManager = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                context.getSystemService(SmsManager::class.java)
            } else {
                @Suppress("DEPRECATION")
                SmsManager.getDefault()
            }

            val parts = smsManager.divideMessage(message)
            if (parts.size > 1) {
                val sentIntents = ArrayList<PendingIntent?>()
                for (i in parts.indices) {
                    sentIntents.add(if (i == 0) sentIntent else null)
                }
                smsManager.sendMultipartTextMessage(cleanPhone, null, parts, sentIntents, null)
            } else {
                smsManager.sendTextMessage(cleanPhone, null, message, sentIntent, null)
            }
            Pair(true, null)
        } catch (e: Exception) {
            Pair(false, e.localizedMessage ?: "خطأ أثناء إرسال الرسالة عبر النظام")
        }
    }

    /**
     * Fallback to open the user's default SMS app with prefilled phone and body.
     * Guaranteed to work on 100% of Android devices without special carrier permissions.
     */
    fun openSmsAppIntent(context: Context, phoneNumber: String, message: String): Intent {
        val cleanPhone = phoneNumber.trim().replace(" ", "")
        val uri = Uri.parse("smsto:$cleanPhone")
        val intent = Intent(Intent.ACTION_SENDTO, uri).apply {
            putExtra("sms_body", message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return intent
    }
}
