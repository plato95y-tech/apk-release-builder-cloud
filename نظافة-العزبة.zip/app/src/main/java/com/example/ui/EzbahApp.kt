package com.example.ui

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.EventBusy
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.People
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppDatabase
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.DailyPlanEntity
import com.example.data.repository.EzbahRepository
import com.example.domain.scheduler.FairScheduler
import com.example.platform.sms.SmsManagerHelper
import com.example.ui.screens.AbsencesScreen
import com.example.ui.screens.AreasAndTasksScreen
import com.example.ui.screens.BackupScreen
import com.example.ui.screens.CompletionScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.PeopleScreen
import com.example.ui.screens.PlannerScreen
import com.example.ui.screens.ReportsScreen
import com.example.ui.screens.SmsHubScreen
import kotlinx.coroutines.launch
import java.util.UUID

import com.example.data.preferences.AppPreferences
import com.example.ui.screens.SettingsScreen
import androidx.compose.material.icons.filled.Settings

enum class AppDestination(val titleAr: String) {
    DASHBOARD("الرئيسية"),
    PLANNER("مخطط التوزيع"),
    COMPLETION("سجل الإنجاز"),
    SMS_HUB("مركز الرسائل"),
    PEOPLE("أفراد العزبة"),
    AREAS_TASKS("المناطق والمهام"),
    ABSENCES("سجل الغياب"),
    REPORTS("التقارير والإحصائيات"),
    BACKUP("النسخ الاحتياطي"),
    SETTINGS("الإعدادات")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EzbahApp(database: AppDatabase) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val repository = remember { EzbahRepository(database) }
    val preferences = remember { AppPreferences(context) }

    // Seed initial data and cleanup stale sending messages on launch (Section 9)
    LaunchedEffect(Unit) {
        repository.seedInitialDataIfEmpty()
        repository.checkAndCleanStaleSendingMessages()
    }

    val todayDate = remember { FairScheduler.getTodayDate() }
    var currentDestination by remember { mutableStateOf(AppDestination.DASHBOARD) }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)

    // Data observation flows
    val people by repository.peopleFlow.collectAsState(initial = emptyList())
    val areas by repository.areasFlow.collectAsState(initial = emptyList())
    val tasks by repository.tasksFlow.collectAsState(initial = emptyList())
    val absences by repository.absencesFlow.collectAsState(initial = emptyList())
    val outboxMessages by repository.outboxFlow.collectAsState(initial = emptyList())
    val allAssignments by repository.allAssignmentsFlow.collectAsState(initial = emptyList())
    val todayAssignments by repository.getAssignmentsForDateFlow(todayDate).collectAsState(initial = emptyList())
    val todayPlan by repository.getPlanForDateFlow(todayDate).collectAsState(initial = null)
    val auditLogs by repository.auditLogsFlow.collectAsState(initial = emptyList())

    val peopleById = remember(people) { people.associateBy { it.id } }
    val areasById = remember(areas) { areas.associateBy { it.id } }
    val tasksById = remember(tasks) { tasks.associateBy { it.id } }
    val absentPersonIds = remember(absences, todayDate) {
        absences.filter { todayDate in it.startDate..it.endDate }.map { it.personId }.toSet()
    }

    // Back handler: Return to Dashboard if not already there
    BackHandler(enabled = currentDestination != AppDestination.DASHBOARD) {
        currentDestination = AppDestination.DASHBOARD
    }

    // Force RTL for entire application
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        ModalNavigationDrawer(
            drawerState = drawerState,
            drawerContent = {
                ModalDrawerSheet(
                    modifier = Modifier
                        .width(300.dp)
                        .testTag("nav_drawer_sheet")
                ) {
                    // Drawer Header
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(MaterialTheme.colorScheme.primaryContainer)
                            .padding(24.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(44.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(MaterialTheme.colorScheme.primary),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        Icons.Default.CleaningServices,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.onPrimary,
                                        modifier = Modifier.size(26.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "نظافة العزبة",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                    Text(
                                        text = "إصدار 1.0 • Offline-first",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Drawer Items
                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                        label = { Text("الرئيسية") },
                        selected = currentDestination == AppDestination.DASHBOARD,
                        onClick = {
                            currentDestination = AppDestination.DASHBOARD
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                        label = { Text("مخطط التوزيع اليومي") },
                        selected = currentDestination == AppDestination.PLANNER,
                        onClick = {
                            currentDestination = AppDestination.PLANNER
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null) },
                        label = { Text("تسجيل الإنجاز والمتابعة") },
                        selected = currentDestination == AppDestination.COMPLETION,
                        onClick = {
                            currentDestination = AppDestination.COMPLETION
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Message, contentDescription = null) },
                        label = { Text("مركز رسائل التكليفات (SMS)") },
                        selected = currentDestination == AppDestination.SMS_HUB,
                        onClick = {
                            currentDestination = AppDestination.SMS_HUB
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp, horizontal = 16.dp))

                    Text(
                        text = "الإدارة والبيانات",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.People, contentDescription = null) },
                        label = { Text("أفراد العزبة") },
                        selected = currentDestination == AppDestination.PEOPLE,
                        onClick = {
                            currentDestination = AppDestination.PEOPLE
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.CleaningServices, contentDescription = null) },
                        label = { Text("المناطق والمهام") },
                        selected = currentDestination == AppDestination.AREAS_TASKS,
                        onClick = {
                            currentDestination = AppDestination.AREAS_TASKS
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.EventBusy, contentDescription = null) },
                        label = { Text("سجل الغياب والاعتذار") },
                        selected = currentDestination == AppDestination.ABSENCES,
                        onClick = {
                            currentDestination = AppDestination.ABSENCES
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Equalizer, contentDescription = null) },
                        label = { Text("التقارير والإحصائيات") },
                        selected = currentDestination == AppDestination.REPORTS,
                        onClick = {
                            currentDestination = AppDestination.REPORTS
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Backup, contentDescription = null) },
                        label = { Text("النسخ الاحتياطي والاستعادة") },
                        selected = currentDestination == AppDestination.BACKUP,
                        onClick = {
                            currentDestination = AppDestination.BACKUP
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )

                    NavigationDrawerItem(
                        icon = { Icon(Icons.Default.Settings, contentDescription = null) },
                        label = { Text("الإعدادات والقوالب") },
                        selected = currentDestination == AppDestination.SETTINGS,
                        onClick = {
                            currentDestination = AppDestination.SETTINGS
                            scope.launch { drawerState.close() }
                        },
                        modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
                    )
                }
            }
        ) {
            Scaffold(
                topBar = {
                    TopAppBar(
                        title = {
                            Column {
                                Text(
                                    text = "نظافة العزبة",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = currentDestination.titleAr,
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        },
                        navigationIcon = {
                            if (currentDestination == AppDestination.DASHBOARD) {
                                IconButton(
                                    onClick = { scope.launch { drawerState.open() } },
                                    modifier = Modifier.testTag("open_drawer_button")
                                ) {
                                    Icon(Icons.Default.Menu, contentDescription = "القائمة")
                                }
                            } else {
                                IconButton(onClick = { currentDestination = AppDestination.DASHBOARD }) {
                                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "الرجوع")
                                }
                            }
                        },
                        colors = TopAppBarDefaults.topAppBarColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        )
                    )
                },
                bottomBar = {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface
                    ) {
                        NavigationBarItem(
                            selected = currentDestination == AppDestination.DASHBOARD,
                            onClick = { currentDestination = AppDestination.DASHBOARD },
                            icon = { Icon(Icons.Default.Dashboard, contentDescription = null) },
                            label = { Text("الرئيسية") },
                            modifier = Modifier.testTag("nav_dashboard")
                        )
                        NavigationBarItem(
                            selected = currentDestination == AppDestination.PLANNER,
                            onClick = { currentDestination = AppDestination.PLANNER },
                            icon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                            label = { Text("المخطط") },
                            modifier = Modifier.testTag("nav_planner")
                        )
                        NavigationBarItem(
                            selected = currentDestination == AppDestination.COMPLETION,
                            onClick = { currentDestination = AppDestination.COMPLETION },
                            icon = { Icon(Icons.Default.AssignmentTurnedIn, contentDescription = null) },
                            label = { Text("الإنجاز") },
                            modifier = Modifier.testTag("nav_completion")
                        )
                        NavigationBarItem(
                            selected = currentDestination == AppDestination.SMS_HUB,
                            onClick = { currentDestination = AppDestination.SMS_HUB },
                            icon = { Icon(Icons.Default.Message, contentDescription = null) },
                            label = { Text("الرسائل") },
                            modifier = Modifier.testTag("nav_sms")
                        )
                        NavigationBarItem(
                            selected = currentDestination in listOf(
                                AppDestination.PEOPLE,
                                AppDestination.AREAS_TASKS,
                                AppDestination.ABSENCES,
                                AppDestination.REPORTS,
                                AppDestination.BACKUP
                            ),
                            onClick = { scope.launch { drawerState.open() } },
                            icon = { Icon(Icons.Default.Menu, contentDescription = null) },
                            label = { Text("المزيد") },
                            modifier = Modifier.testTag("nav_more")
                        )
                    }
                }
            ) { innerPadding ->
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(innerPadding)
                ) {
                    when (currentDestination) {
                        AppDestination.DASHBOARD -> DashboardScreen(
                            todayDate = todayDate,
                            todayPlan = todayPlan,
                            todayAssignments = todayAssignments,
                            peopleById = peopleById,
                            tasksById = tasksById,
                            areasById = areasById,
                            outboxMessages = outboxMessages,
                            onNavigateToPlanner = { currentDestination = AppDestination.PLANNER },
                            onNavigateToCompletion = { currentDestination = AppDestination.COMPLETION },
                            onNavigateToSms = { currentDestination = AppDestination.SMS_HUB },
                            onQuickToggleComplete = { asgId, isComp ->
                                scope.launch {
                                    repository.updateAssignmentStatus(
                                        asgId,
                                        if (isComp) "COMPLETED" else "PENDING"
                                    )
                                }
                            }
                        )

                        AppDestination.PLANNER -> PlannerScreen(
                            currentDate = todayDate,
                            existingPlan = todayPlan,
                            existingAssignments = todayAssignments,
                            people = people,
                            tasks = tasks,
                            areas = areas,
                            past14DaysAssignments = allAssignments,
                            absentPersonIds = absentPersonIds,
                            onApprovePlan = { date, propList ->
                                scope.launch {
                                    val planId = todayPlan?.id ?: UUID.randomUUID().toString()
                                    val plan = DailyPlanEntity(
                                        id = planId,
                                        planDate = date,
                                        status = "APPROVED",
                                        version = (todayPlan?.version ?: 0) + 1,
                                        approvedAt = System.currentTimeMillis()
                                    )
                                    val entities = propList.map { prop ->
                                        DailyAssignmentEntity(
                                            id = prop.id,
                                            planId = planId,
                                            taskId = prop.taskId,
                                            personId = prop.personId,
                                            assignmentDate = date,
                                            effortPointsSnapshot = prop.effortPoints,
                                            status = "PENDING",
                                            notes = prop.reasonNote
                                        )
                                    }
                                    repository.approvePlanAndAssignments(plan, entities)
                                    Toast.makeText(context, "تم اعتماد الجدول رسمياً وحفظه!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onPrepareSms = { planId, date ->
                                scope.launch {
                                    val count = repository.prepareSmsOutboxForPlan(planId, date, dueTime = preferences.defaultDueTime)
                                    Toast.makeText(context, "تم تجهيز $count رسائل في صندوق SMS!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onNavigateToSms = { currentDestination = AppDestination.SMS_HUB }
                        )

                        AppDestination.COMPLETION -> CompletionScreen(
                            currentDate = todayDate,
                            assignments = allAssignments,
                            peopleById = peopleById,
                            allPeople = people,
                            tasksById = tasksById,
                            areasById = areasById,
                            onUpdateStatus = { asgId, newStatus, notes ->
                                scope.launch {
                                    repository.updateAssignmentStatus(asgId, newStatus, notes)
                                }
                            },
                            onReassignTask = { asgId, newPersonId, reason ->
                                scope.launch {
                                    repository.reassignAssignment(asgId, newPersonId, reason)
                                    Toast.makeText(context, "تمت إعادة تعيين المهمة وتوثيقها بسجل التدقيق.", Toast.LENGTH_SHORT).show()
                                }
                            }
                        )

                        AppDestination.SMS_HUB -> SmsHubScreen(
                            outboxMessages = outboxMessages,
                            peopleById = peopleById,
                            onSendDirect = { msg ->
                                scope.launch {
                                    repository.updateMessageStatus(msg.id, "SENDING")
                                    val (success, err) = SmsManagerHelper.sendDirectSms(
                                        context,
                                        msg.recipientPhoneSnapshot,
                                        msg.bodySnapshot
                                    )
                                    repository.recordSmsAttempt(
                                        messageId = msg.id,
                                        result = if (success) "SUCCESS" else "GENERIC_FAILURE",
                                        errorSummary = err
                                    )
                                    if (success) {
                                        Toast.makeText(context, "تم إرسال الرسالة إلى الشبكة بنجاح", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "فشل الإرسال: $err", Toast.LENGTH_LONG).show()
                                    }
                                }
                            },
                            onRetryMessage = { msgId ->
                                scope.launch {
                                    repository.updateMessageStatus(msgId, "QUEUED")
                                }
                            },
                            onMarkUnknown = { msgId ->
                                scope.launch {
                                    repository.updateMessageStatus(msgId, "UNKNOWN")
                                }
                            }
                        )

                        AppDestination.PEOPLE -> PeopleScreen(
                            people = people,
                            onSavePerson = { person ->
                                scope.launch { repository.savePerson(person) }
                            },
                            onDeletePerson = { person ->
                                scope.launch { repository.deletePerson(person) }
                            }
                        )

                        AppDestination.AREAS_TASKS -> AreasAndTasksScreen(
                            tasks = tasks,
                            areas = areas,
                            onSaveTask = { task ->
                                scope.launch { repository.saveTask(task) }
                            },
                            onDeleteTask = { task ->
                                scope.launch { repository.deleteTask(task) }
                            },
                            onSaveArea = { area ->
                                scope.launch { repository.saveArea(area) }
                            },
                            onDeleteArea = { area ->
                                scope.launch { repository.deleteArea(area) }
                            }
                        )

                        AppDestination.ABSENCES -> AbsencesScreen(
                            absences = absences,
                            people = people,
                            onSaveAbsence = { absence ->
                                scope.launch { repository.saveAbsence(absence) }
                            },
                            onDeleteAbsence = { absence ->
                                scope.launch { repository.deleteAbsence(absence) }
                            }
                        )

                        AppDestination.REPORTS -> ReportsScreen(
                            assignments = allAssignments,
                            people = people,
                            tasks = tasks
                        )

                        AppDestination.BACKUP -> BackupScreen(
                            database = database,
                            auditLogs = auditLogs
                        )

                        AppDestination.SETTINGS -> SettingsScreen(
                            preferences = preferences
                        )
                    }
                }
            }
        }
    }
}
