package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Switch
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CleaningAreaEntity
import com.example.data.local.entity.CleaningTaskEntity
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AreasAndTasksScreen(
    tasks: List<CleaningTaskEntity>,
    areas: List<CleaningAreaEntity>,
    onSaveTask: (CleaningTaskEntity) -> Unit,
    onDeleteTask: (CleaningTaskEntity) -> Unit,
    onSaveArea: (CleaningAreaEntity) -> Unit,
    onDeleteArea: (CleaningAreaEntity) -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) }
    var taskToEdit by remember { mutableStateOf<CleaningTaskEntity?>(null) }
    var isAddingTask by remember { mutableStateOf(false) }
    var areaToEdit by remember { mutableStateOf<CleaningAreaEntity?>(null) }
    var isAddingArea by remember { mutableStateOf(false) }

    val areaNamesById = remember(areas) { areas.associate { it.id to it.name } }

    Box(modifier = Modifier.fillMaxSize().testTag("areas_and_tasks_screen")) {
        Column(modifier = Modifier.fillMaxSize()) {
            PrimaryTabRow(selectedTabIndex = selectedTab) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("مهام النظافة (${tasks.size})", fontWeight = FontWeight.SemiBold) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("مناطق العزبة (${areas.size})", fontWeight = FontWeight.SemiBold) }
                )
            }

            if (selectedTab == 0) {
                // Tasks List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(tasks) { task ->
                        val areaName = areaNamesById[task.areaId] ?: "منطقة غير محددة"
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = task.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(8.dp))
                                                .background(
                                                    when (task.effortPoints) {
                                                        3 -> StatusError.copy(alpha = 0.12f)
                                                        2 -> StatusWarning.copy(alpha = 0.12f)
                                                        else -> StatusSuccess.copy(alpha = 0.12f)
                                                    }
                                                )
                                                .padding(horizontal = 8.dp, vertical = 2.dp)
                                        ) {
                                            Text(
                                                text = when (task.effortPoints) {
                                                    3 -> "شاق (3 نقاط)"
                                                    2 -> "متوسط (نقطتان)"
                                                    else -> "خفيف (نقطة)"
                                                },
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when (task.effortPoints) {
                                                    3 -> StatusError
                                                    2 -> StatusWarning
                                                    else -> StatusSuccess
                                                }
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            Icons.Default.LocationOn,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = areaName,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                        Spacer(modifier = Modifier.width(12.dp))
                                        Icon(
                                            Icons.Default.Timer,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = "${task.estimatedMinutes ?: 30} دقيقة • مطلوب ${task.requiredPeople} أفراد",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    if (!task.instructions.isNullOrBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "تعليمات: ${task.instructions}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                        )
                                    }
                                }

                                Switch(
                                    checked = task.isActive,
                                    onCheckedChange = { isChecked ->
                                        onSaveTask(task.copy(isActive = isChecked, updatedAt = System.currentTimeMillis()))
                                    }
                                )

                                IconButton(onClick = { taskToEdit = task }) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                                }

                                IconButton(onClick = { onDeleteTask(task) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StatusError)
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            } else {
                // Areas List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(areas) { area ->
                        val tasksInArea = tasks.count { it.areaId == area.id }
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = area.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (!area.description.isNullOrBlank()) {
                                        Text(
                                            text = area.description,
                                            style = MaterialTheme.typography.bodySmall,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "$tasksInArea مهام مسجلة بهذه المنطقة",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                Switch(
                                    checked = area.isActive,
                                    onCheckedChange = { isChecked ->
                                        onSaveArea(area.copy(isActive = isChecked, updatedAt = System.currentTimeMillis()))
                                    }
                                )

                                IconButton(onClick = { areaToEdit = area }) {
                                    Icon(Icons.Default.Edit, contentDescription = "تعديل", tint = MaterialTheme.colorScheme.primary)
                                }

                                IconButton(onClick = { onDeleteArea(area) }) {
                                    Icon(Icons.Default.Delete, contentDescription = "حذف", tint = StatusError)
                                }
                            }
                        }
                    }

                    item { Spacer(modifier = Modifier.height(72.dp)) }
                }
            }
        }

        FloatingActionButton(
            onClick = {
                if (selectedTab == 0) isAddingTask = true
                else isAddingArea = true
            },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_item_fab"),
            containerColor = MaterialTheme.colorScheme.primary
        ) {
            Icon(Icons.Default.Add, contentDescription = "إضافة")
        }
    }

    // Add or Edit Task Dialog
    if (isAddingTask || taskToEdit != null) {
        val target = taskToEdit
        var nameInput by remember { mutableStateOf(target?.name ?: "") }
        var areaIdInput by remember { mutableStateOf(target?.areaId ?: areas.firstOrNull()?.id ?: "") }
        var effortInput by remember { mutableIntStateOf(target?.effortPoints ?: 1) }
        var minutesInput by remember { mutableStateOf((target?.estimatedMinutes ?: 30).toString()) }
        var requiredPeopleInput by remember { mutableStateOf((target?.requiredPeople ?: 1).toString()) }
        var instructionsInput by remember { mutableStateOf(target?.instructions ?: "") }
        var isNameError by remember { mutableStateOf(false) }
        var areaDropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = {
                isAddingTask = false
                taskToEdit = null
            },
            title = { Text(if (target == null) "إضافة مهمة نظافة" else "تعديل مهمة النظافة") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        OutlinedTextField(
                            value = nameInput,
                            onValueChange = {
                                nameInput = it
                                isNameError = it.isBlank()
                            },
                            label = { Text("اسم المهمة *") },
                            isError = isNameError,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    item {
                        ExposedDropdownMenuBox(
                            expanded = areaDropdownExpanded,
                            onExpandedChange = { areaDropdownExpanded = it }
                        ) {
                            val currentAreaName = areaNamesById[areaIdInput] ?: "اختر المنطقة"
                            OutlinedTextField(
                                value = currentAreaName,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("منطقة النظافة") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = areaDropdownExpanded) },
                                modifier = Modifier
                                    .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                    .fillMaxWidth()
                            )
                            ExposedDropdownMenu(
                                expanded = areaDropdownExpanded,
                                onDismissRequest = { areaDropdownExpanded = false }
                            ) {
                                areas.forEach { a ->
                                    DropdownMenuItem(
                                        text = { Text(a.name) },
                                        onClick = {
                                            areaIdInput = a.id
                                            areaDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Text("مستوى الجهد:", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(1 to "خفيف (1)", 2 to "متوسط (2)", 3 to "شاق (3)").forEach { (pts, label) ->
                                val isSelected = effortInput == pts
                                Box(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(
                                            if (isSelected) MaterialTheme.colorScheme.primary
                                            else MaterialTheme.colorScheme.surfaceVariant
                                        )
                                        .padding(vertical = 10.dp)
                                        .testTag("effort_${pts}_btn"),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = label,
                                        color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp)
                                    )
                                }
                            }
                        }
                    }

                    item {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(
                                value = minutesInput,
                                onValueChange = { minutesInput = it.filter { ch -> ch.isDigit() } },
                                label = { Text("المدة (دقيقة)") },
                                modifier = Modifier.weight(1f)
                            )
                            OutlinedTextField(
                                value = requiredPeopleInput,
                                onValueChange = { requiredPeopleInput = it.filter { ch -> ch.isDigit() } },
                                label = { Text("عدد الأفراد") },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    item {
                        OutlinedTextField(
                            value = instructionsInput,
                            onValueChange = { instructionsInput = it },
                            label = { Text("تعليمات المهمة (اختياري)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isBlank()) {
                            isNameError = true
                            return@Button
                        }
                        val pts = effortInput.coerceIn(1, 3)
                        val mins = minutesInput.toIntOrNull() ?: 30
                        val req = requiredPeopleInput.toIntOrNull()?.coerceAtLeast(1) ?: 1

                        val entity = target?.copy(
                            name = nameInput.trim(),
                            areaId = areaIdInput,
                            effortPoints = pts,
                            estimatedMinutes = mins,
                            requiredPeople = req,
                            instructions = instructionsInput.ifBlank { null },
                            updatedAt = System.currentTimeMillis()
                        ) ?: CleaningTaskEntity(
                            name = nameInput.trim(),
                            areaId = areaIdInput,
                            effortPoints = pts,
                            estimatedMinutes = mins,
                            requiredPeople = req,
                            instructions = instructionsInput.ifBlank { null }
                        )
                        onSaveTask(entity)
                        isAddingTask = false
                        taskToEdit = null
                    }
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    isAddingTask = false
                    taskToEdit = null
                }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Add or Edit Area Dialog
    if (isAddingArea || areaToEdit != null) {
        val target = areaToEdit
        var nameInput by remember { mutableStateOf(target?.name ?: "") }
        var descInput by remember { mutableStateOf(target?.description ?: "") }
        var isNameError by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = {
                isAddingArea = false
                areaToEdit = null
            },
            title = { Text(if (target == null) "إضافة منطقة جديدة" else "تعديل المنطقة") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = nameInput,
                        onValueChange = {
                            nameInput = it
                            isNameError = it.isBlank()
                        },
                        label = { Text("اسم المنطقة *") },
                        isError = isNameError,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = descInput,
                        onValueChange = { descInput = it },
                        label = { Text("وصف المنطقة (اختياري)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (nameInput.isBlank()) {
                            isNameError = true
                            return@Button
                        }
                        val entity = target?.copy(
                            name = nameInput.trim(),
                            description = descInput.ifBlank { null },
                            updatedAt = System.currentTimeMillis()
                        ) ?: CleaningAreaEntity(
                            name = nameInput.trim(),
                            description = descInput.ifBlank { null }
                        )
                        onSaveArea(entity)
                        isAddingArea = false
                        areaToEdit = null
                    }
                ) {
                    Text("حفظ")
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    isAddingArea = false
                    areaToEdit = null
                }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
