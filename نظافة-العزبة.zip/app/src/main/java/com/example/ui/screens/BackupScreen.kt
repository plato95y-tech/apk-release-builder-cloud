package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Backup
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.backup.BackupManager
import com.example.backup.BackupPreview
import com.example.data.local.AppDatabase
import com.example.data.local.entity.AuditLogEntity
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun BackupScreen(
    database: AppDatabase,
    auditLogs: List<AuditLogEntity>
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var jsonInput by remember { mutableStateOf("") }
    var backupPreview by remember { mutableStateOf<BackupPreview?>(null) }
    var showConfirmRestoreDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("backup_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Export Section
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Backup,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "تصدير نسخة احتياطية (JSON)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "يتم حفظ كافة الأفراد والمناطق والمهام والغياب والتكليفات في ملف JSON متوافق مع المخطط الرسمي.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = {
                                scope.launch {
                                    val json = BackupManager.exportDatabaseToJson(database)
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    clipboard.setPrimaryClip(ClipData.newPlainText("Ezbah Backup JSON", json))
                                    Toast.makeText(context, "تم نسخ النسخة الاحتياطية (JSON) للحافظة!", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("نسخ JSON للحافظة")
                        }

                        OutlinedButton(
                            onClick = {
                                scope.launch {
                                    val json = BackupManager.exportDatabaseToJson(database)
                                    val sendIntent = Intent().apply {
                                        action = Intent.ACTION_SEND
                                        putExtra(Intent.EXTRA_TEXT, json)
                                        type = "application/json"
                                    }
                                    val shareIntent = Intent.createChooser(sendIntent, "مشاركة نسخة احتياطية")
                                    context.startActivity(shareIntent)
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("مشاركة الملف")
                        }
                    }
                }
            }
        }

        // Import Section
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Restore,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "استعادة البيانات من JSON",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "الصق نص JSON للنسخة الاحتياطية هنا ثم اضغط «معاينة وتحقق» قبل الاستبدال.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = jsonInput,
                        onValueChange = { jsonInput = it },
                        label = { Text("محتوى JSON...") },
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            if (jsonInput.isBlank()) {
                                Toast.makeText(context, "الرجاء لصق نص JSON أولاً", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            backupPreview = BackupManager.inspectBackup(jsonInput)
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("معاينة والتحقق من الملف")
                    }

                    // Preview Details
                    backupPreview?.let { preview ->
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (preview.isValid) StatusSuccess.copy(alpha = 0.08f) else StatusError.copy(alpha = 0.08f)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                if (preview.isValid) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("الملف سليم ومتوافق (إصدار ${preview.schemaVersion})", fontWeight = FontWeight.Bold, color = StatusSuccess)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text("تاريخ النسخة: ${preview.exportedAt}", fontSize = 12.sp)
                                    Text("الأفراد: ${preview.peopleCount} • المناطق: ${preview.areasCount} • المهام: ${preview.tasksCount}", fontSize = 12.sp)
                                    Text("التكليفات: ${preview.assignmentsCount} • الغياب: ${preview.absencesCount}", fontSize = 12.sp)

                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = { showConfirmRestoreDialog = true },
                                        colors = ButtonDefaults.buttonColors(containerColor = StatusWarning),
                                        modifier = Modifier.fillMaxWidth()
                                    ) {
                                        Text("تأكيد استعادة هذه النسخة")
                                    }
                                } else {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Warning, contentDescription = null, tint = StatusError)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("الملف غير صالح", fontWeight = FontWeight.Bold, color = StatusError)
                                    }
                                    Text(preview.errorMessage ?: "خطأ غير محدد", color = StatusError, fontSize = 12.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Audit Logs Section
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.History, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "سجل أحداث وتغييرات المسؤول (${auditLogs.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        items(auditLogs.take(20)) { log ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.primaryContainer)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = log.eventType,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        val formattedDate = SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US).format(Date(log.createdAt))
                        Text(text = formattedDate, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(text = log.details, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }

    if (showConfirmRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showConfirmRestoreDialog = false },
            title = { Text("تأكيد الاستعادة واستبدال البيانات") },
            text = {
                Text("هل أنت متأكد من رغبتك في استعادة هذه النسخة؟ سيتم دمج وتحديث السجلات ولن تُرسل الرسائل القديمة تلقائياً.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        scope.launch {
                            val (success, msg) = BackupManager.restoreDatabaseFromJson(database, jsonInput)
                            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            showConfirmRestoreDialog = false
                            backupPreview = null
                            jsonInput = ""
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusWarning)
                ) {
                    Text("نعم، استعادة الآن")
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmRestoreDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}
