package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AssignmentTurnedIn
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Note
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CleaningAreaEntity
import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.PersonEntity
import com.example.domain.model.AssignmentStatus
import com.example.platform.sms.SmsManagerHelper
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusNeutral
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning

@Composable
fun CompletionScreen(
    currentDate: String,
    assignments: List<DailyAssignmentEntity>,
    peopleById: Map<String, PersonEntity>,
    allPeople: List<PersonEntity>,
    tasksById: Map<String, CleaningTaskEntity>,
    areasById: Map<String, CleaningAreaEntity>,
    onUpdateStatus: (assignmentId: String, newStatus: String, notes: String?) -> Unit,
    onReassignTask: (assignmentId: String, newPersonId: String, reason: String) -> Unit
) {
    val context = LocalContext.current
    var selectedDate by remember { mutableStateOf(currentDate) }
    var assignmentForNotes by remember { mutableStateOf<DailyAssignmentEntity?>(null) }
    var assignmentForReassign by remember { mutableStateOf<DailyAssignmentEntity?>(null) }

    val filteredAssignments = remember(assignments, selectedDate) {
        assignments.filter { it.assignmentDate == selectedDate }
    }

    val completedCount = filteredAssignments.count { it.status == "COMPLETED" }
    val pendingCount = filteredAssignments.count { it.status == "PENDING" }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("completion_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Date Selector & Stats
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "متابعة وتسجيل الإنجاز",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "$completedCount منجز • $pendingCount متبقي",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = selectedDate,
                        onValueChange = { selectedDate = it },
                        label = { Text("التاريخ (YYYY-MM-DD)") },
                        leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        if (filteredAssignments.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.HourglassEmpty,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "لا توجد تكليفات مسجلة في هذا التاريخ",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "انتقل إلى شاشة المخطط لإنشاء واعتماد جدول نظافة لهذا اليوم.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredAssignments) { asg ->
                val person = peopleById[asg.personId]
                val task = tasksById[asg.taskId]
                val area = task?.let { areasById[it.areaId] }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = when (asg.status) {
                            "COMPLETED" -> StatusSuccess.copy(alpha = 0.08f)
                            "OVERDUE" -> StatusError.copy(alpha = 0.08f)
                            "EXCUSED" -> StatusNeutral.copy(alpha = 0.08f)
                            else -> MaterialTheme.colorScheme.surface
                        }
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.Person,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = person?.name ?: "غير محدد",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Text(
                                    text = "${task?.name ?: "مهمة"} • ${area?.name ?: ""}",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            // Status Chip
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when (asg.status) {
                                            "COMPLETED" -> StatusSuccess.copy(alpha = 0.15f)
                                            "OVERDUE" -> StatusError.copy(alpha = 0.15f)
                                            "EXCUSED" -> StatusNeutral.copy(alpha = 0.15f)
                                            "CANCELLED" -> MaterialTheme.colorScheme.outline.copy(alpha = 0.15f)
                                            else -> StatusWarning.copy(alpha = 0.15f)
                                        }
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                val label = try {
                                    AssignmentStatus.valueOf(asg.status).labelAr
                                } catch (_: Exception) {
                                    asg.status
                                }
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (asg.status) {
                                        "COMPLETED" -> StatusSuccess
                                        "OVERDUE" -> StatusError
                                        "EXCUSED" -> StatusNeutral
                                        "CANCELLED" -> MaterialTheme.colorScheme.outline
                                        else -> StatusWarning
                                    }
                                )
                            }
                        }

                        if (!asg.notes.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "ملاحظات: ${asg.notes}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Actions Row: Complete, Excused, Overdue, Notes, Reminder SMS
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Complete button
                            OutlinedButton(
                                onClick = { onUpdateStatus(asg.id, "COMPLETED", null) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تم", fontSize = 11.sp)
                            }

                            // Excused button
                            OutlinedButton(
                                onClick = { onUpdateStatus(asg.id, "EXCUSED", null) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("معذور", fontSize = 11.sp)
                            }

                            // Overdue button
                            OutlinedButton(
                                onClick = { onUpdateStatus(asg.id, "OVERDUE", null) },
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("متأخر", fontSize = 11.sp)
                            }

                            // Reassign button (FR-06)
                            IconButton(onClick = { assignmentForReassign = asg }) {
                                Icon(Icons.Default.Person, contentDescription = "إعادة تعيين لشخص آخر", tint = MaterialTheme.colorScheme.tertiary)
                            }

                            // Add Notes button
                            IconButton(onClick = { assignmentForNotes = asg }) {
                                Icon(Icons.Default.Note, contentDescription = "ملاحظات", tint = MaterialTheme.colorScheme.primary)
                            }

                            // Send Reminder SMS button
                            IconButton(onClick = {
                                if (person != null && person.phoneNumber.isNotBlank()) {
                                    val reminderBody = SmsManagerHelper.formatReminderMessage(
                                        taskName = task?.name ?: "المهمة",
                                        assignmentCode = asg.id
                                    )
                                    val intent = SmsManagerHelper.openSmsAppIntent(context, person.phoneNumber, reminderBody)
                                    context.startActivity(intent)
                                } else {
                                    Toast.makeText(context, "لا يوجد رقم هاتف مسجل للمستلم", Toast.LENGTH_SHORT).show()
                                }
                            }) {
                                Icon(Icons.Default.Message, contentDescription = "تذكير SMS", tint = MaterialTheme.colorScheme.secondary)
                            }
                        }
                    }
                }
            }
        }
    }

    // Reassign Dialog (FR-06 & NFR-03)
    assignmentForReassign?.let { asg ->
        var selectedNewPersonId by remember { mutableStateOf(allPeople.firstOrNull { it.id != asg.personId && it.isActive }?.id ?: "") }
        var reassignReason by remember { mutableStateOf("") }
        val task = tasksById[asg.taskId]

        AlertDialog(
            onDismissRequest = { assignmentForReassign = null },
            title = { Text("إعادة تعيين المهمة لشخص آخر") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "المهمة: ${task?.name ?: "مهمة نظافة"}",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "اختر الفرد البديل واذكر سبب إعادة التعيين لتوثيقه في سجل التدقيق:",
                        style = MaterialTheme.typography.bodySmall
                    )

                    allPeople.filter { it.isActive && it.id != asg.personId }.forEach { p ->
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(
                                    if (selectedNewPersonId == p.id) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                )
                                .padding(8.dp)
                        ) {
                            Text(
                                text = p.name,
                                modifier = Modifier.weight(1f),
                                fontWeight = if (selectedNewPersonId == p.id) FontWeight.Bold else FontWeight.Normal
                            )
                            Button(
                                onClick = { selectedNewPersonId = p.id },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (selectedNewPersonId == p.id) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline
                                )
                            ) {
                                Text(if (selectedNewPersonId == p.id) "محدد" else "اختيار", fontSize = 11.sp)
                            }
                        }
                    }

                    OutlinedTextField(
                        value = reassignReason,
                        onValueChange = { reassignReason = it },
                        label = { Text("سبب إعادة التعيين (مثال: اعتذار طارئ / تبديل رضائي)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (selectedNewPersonId.isNotBlank()) {
                            onReassignTask(asg.id, selectedNewPersonId, reassignReason.ifBlank { "إعادة تعيين من المسؤول" })
                            assignmentForReassign = null
                        }
                    }
                ) {
                    Text("تأكيد التبديل")
                }
            },
            dismissButton = {
                TextButton(onClick = { assignmentForReassign = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Notes Dialog
    assignmentForNotes?.let { asg ->
        var notesText by remember { mutableStateOf(asg.notes ?: "") }
        AlertDialog(
            onDismissRequest = { assignmentForNotes = null },
            title = { Text("تسجيل ملاحظات على التكليف") },
            text = {
                OutlinedTextField(
                    value = notesText,
                    onValueChange = { notesText = it },
                    label = { Text("اكتب الملاحظات هنا...") },
                    modifier = Modifier.fillMaxWidth()
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onUpdateStatus(asg.id, asg.status, notesText.ifBlank { null })
                        assignmentForNotes = null
                    }
                ) {
                    Text("حفظ الملاحظة")
                }
            },
            dismissButton = {
                TextButton(onClick = { assignmentForNotes = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

