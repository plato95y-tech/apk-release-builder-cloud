package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MenuAnchorType
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.CleaningAreaEntity
import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.DailyPlanEntity
import com.example.data.local.entity.PersonEntity
import com.example.domain.scheduler.FairScheduler
import com.example.domain.scheduler.ProposedAssignment
import com.example.domain.scheduler.ScheduleProposal
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlannerScreen(
    currentDate: String,
    existingPlan: DailyPlanEntity?,
    existingAssignments: List<DailyAssignmentEntity>,
    people: List<PersonEntity>,
    tasks: List<CleaningTaskEntity>,
    areas: List<CleaningAreaEntity>,
    past14DaysAssignments: List<DailyAssignmentEntity>,
    absentPersonIds: Set<String>,
    onApprovePlan: (date: String, assignments: List<ProposedAssignment>) -> Unit,
    onPrepareSms: (planId: String, date: String) -> Unit,
    onNavigateToSms: () -> Unit
) {
    var selectedDate by remember { mutableStateOf(currentDate) }
    var currentProposal by remember { mutableStateOf<ScheduleProposal?>(null) }
    val editableAssignments = remember { mutableStateListOf<ProposedAssignment>() }
    var showReassignDialogForIndex by remember { mutableStateOf<Int?>(null) }
    var showSuccessApproveDialog by remember { mutableStateOf(false) }

    val areaNamesById = remember(areas) { areas.associate { it.id to it.name } }
    val availableActivePeople = remember(people, absentPersonIds) {
        people.filter { it.isActive && it.id !in absentPersonIds }
    }

    // Initialize with existing assignments if already present and proposal is null
    remember(existingAssignments, existingPlan) {
        if (existingAssignments.isNotEmpty() && currentProposal == null) {
            val peopleMap = people.associateBy { it.id }
            val taskMap = tasks.associateBy { it.id }
            editableAssignments.clear()
            existingAssignments.forEach { asg ->
                val p = peopleMap[asg.personId]
                val t = taskMap[asg.taskId]
                val aName = t?.let { areaNamesById[it.areaId] } ?: "المنطقة"
                editableAssignments.add(
                    ProposedAssignment(
                        id = asg.id,
                        taskId = asg.taskId,
                        taskName = t?.name ?: "مهمة",
                        areaName = aName,
                        personId = asg.personId,
                        personName = p?.name ?: "غير محدد",
                        effortPoints = asg.effortPointsSnapshot,
                        reasonNote = asg.notes ?: "تكليف معتمد"
                    )
                )
            }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("planner_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Plan Date & Generator Header
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "مخطط التوزيع العادل اليومي",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = selectedDate,
                        onValueChange = { selectedDate = it },
                        label = { Text("تاريخ اليوم (YYYY-MM-DD)") },
                        leadingIcon = { Icon(Icons.Default.DateRange, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    var showRegenerateWarningDialog by remember { mutableStateOf(false) }

                    val runGeneration = {
                        val proposal = FairScheduler.generateProposal(
                            date = selectedDate,
                            activePeople = people,
                            absentPersonIds = absentPersonIds,
                            tasks = tasks.filter { it.isActive },
                            areaNamesById = areaNamesById,
                            past14DaysAssignments = past14DaysAssignments,
                            yesterdayDate = FairScheduler.getYesterdayDate(selectedDate)
                        )
                        currentProposal = proposal
                        editableAssignments.clear()
                        editableAssignments.addAll(proposal.proposedAssignments)
                    }

                    Button(
                        onClick = {
                            if (existingPlan?.status == "APPROVED" && existingAssignments.isNotEmpty()) {
                                showRegenerateWarningDialog = true
                            } else {
                                runGeneration()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_schedule_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("توليد التوزيع العادل آلياً")
                    }

                    if (showRegenerateWarningDialog) {
                        AlertDialog(
                            onDismissRequest = { showRegenerateWarningDialog = false },
                            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = StatusWarning) },
                            title = { Text("تحذير: الخطة معتمدة مسبقاً (FR-04)") },
                            text = {
                                Text("يوجد جدول معتمد رسمياً لتاريخ $selectedDate. إعادة التوليد ستستبدل التكليفات الحالية وتنشئ نسخة جديدة برقم إصدار أعلى. هل ترغب في المتابعة؟")
                            },
                            confirmButton = {
                                Button(
                                    onClick = {
                                        showRegenerateWarningDialog = false
                                        runGeneration()
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusWarning)
                                ) {
                                    Text("نعم، إعادة التوليد")
                                }
                            },
                            dismissButton = {
                                TextButton(onClick = { showRegenerateWarningDialog = false }) {
                                    Text("إلغاء")
                                }
                            }
                        )
                    }
                }
            }
        }

        // 2. Warnings and Uncovered Tasks Banners
        currentProposal?.let { prop ->
            if (prop.uncoveredTasks.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StatusError.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = StatusError)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "مهام غير مغطاة بالكامل (${prop.uncoveredTasks.size})",
                                    fontWeight = FontWeight.Bold,
                                    color = StatusError
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            prop.uncoveredTasks.forEach { unc ->
                                Text(
                                    text = "• ${unc.taskName} (${unc.areaName}): ${unc.reason}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusError
                                )
                            }
                        }
                    }
                }
            }

            if (prop.warnings.isNotEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = StatusWarning.copy(alpha = 0.1f)),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Warning, contentDescription = null, tint = StatusWarning)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تنبيهات خوارزمية التوزيع",
                                    fontWeight = FontWeight.Bold,
                                    color = StatusWarning
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            prop.warnings.forEach { w ->
                                Text(
                                    text = "• $w",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusWarning
                                )
                            }
                        }
                    }
                }
            }

            // Fairness Summary Metrics
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.4f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "مؤشرات العدالة والتوازن",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "الأفراد المتاحون: ${prop.fairnessSummary.availablePeopleCount} • إجمالي الجهد الموزع: ${prop.fairnessSummary.totalEffort} نقطة",
                            style = MaterialTheme.typography.bodySmall
                        )
                        Text(
                            text = "الأقل جهداً (14 يوم): ${prop.fairnessSummary.minEffortPerson} • الأكثر جهداً: ${prop.fairnessSummary.maxEffortPerson}",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }

        // 3. Proposed Assignments List
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "التكليفات المقترحة (${editableAssignments.size})",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                if (editableAssignments.isNotEmpty()) {
                    Text(
                        text = "انقر لتعديل الشخص المكلف",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        if (editableAssignments.isEmpty()) {
            item {
                Text(
                    text = "لم يتم إنشاء أو توليد أي تكليفات لهذا التاريخ حتى الآن.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            itemsIndexed(editableAssignments) { index, item ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            showReassignDialogForIndex = index
                        },
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = item.taskName,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "المنطقة: ${item.areaName}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Person,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = item.personName,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.primary
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when (item.effortPoints) {
                                            3 -> StatusError.copy(alpha = 0.12f)
                                            2 -> StatusWarning.copy(alpha = 0.12f)
                                            else -> StatusSuccess.copy(alpha = 0.12f)
                                        }
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(
                                    text = "${item.effortPoints} نقاط",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (item.effortPoints) {
                                        3 -> StatusError
                                        2 -> StatusWarning
                                        else -> StatusSuccess
                                    }
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "تبديل",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                        }
                    }
                }
            }
        }

        // 4. Approval and SMS Actions
        if (editableAssignments.isNotEmpty()) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Button(
                    onClick = {
                        onApprovePlan(selectedDate, editableAssignments)
                        showSuccessApproveDialog = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("approve_plan_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = StatusSuccess)
                ) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("اعتماد الجدول رسمياً (APPROVED)")
                }
            }

            existingPlan?.let { plan ->
                if (plan.status == "APPROVED") {
                    item {
                        OutlinedButton(
                            onClick = {
                                onPrepareSms(plan.id, selectedDate)
                                onNavigateToSms()
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("prepare_sms_button")
                        ) {
                            Icon(Icons.Default.Message, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("تجهيز رسائل التكليفات في صندوق SMS")
                        }
                    }
                }
            }
        }
    }

    // Manual Reassignment Dialog
    showReassignDialogForIndex?.let { index ->
        val currentItem = editableAssignments[index]
        var selectedNewPersonId by remember { mutableStateOf(currentItem.personId) }
        var dropdownExpanded by remember { mutableStateOf(false) }

        AlertDialog(
            onDismissRequest = { showReassignDialogForIndex = null },
            title = { Text("تعديل الشخص المكلف يدوياً") },
            text = {
                Column {
                    Text(
                        text = "المهمة: ${currentItem.taskName} (${currentItem.effortPoints} نقاط)",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    ExposedDropdownMenuBox(
                        expanded = dropdownExpanded,
                        onExpandedChange = { dropdownExpanded = it }
                    ) {
                        val currentName = people.firstOrNull { it.id == selectedNewPersonId }?.name ?: "اختر الفرد"
                        OutlinedTextField(
                            value = currentName,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("الفرد البديل") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = dropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor(MenuAnchorType.PrimaryNotEditable)
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = dropdownExpanded,
                            onDismissRequest = { dropdownExpanded = false }
                        ) {
                            availableActivePeople.forEach { p ->
                                DropdownMenuItem(
                                    text = { Text(p.name) },
                                    onClick = {
                                        selectedNewPersonId = p.id
                                        dropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val newPerson = people.firstOrNull { it.id == selectedNewPersonId }
                        if (newPerson != null) {
                            editableAssignments[index] = currentItem.copy(
                                personId = newPerson.id,
                                personName = newPerson.name,
                                reasonNote = "تعديل يدوي من المسؤول"
                            )
                        }
                        showReassignDialogForIndex = null
                    }
                ) {
                    Text("حفظ التعديل")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReassignDialogForIndex = null }) {
                    Text("إلغاء")
                }
            }
        )
    }

    // Success Approval Dialog
    if (showSuccessApproveDialog) {
        AlertDialog(
            onDismissRequest = { showSuccessApproveDialog = false },
            icon = { Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusSuccess) },
            title = { Text("تم اعتماد الجدول بنجاح") },
            text = {
                Text("تم حفظ الجدول والتكليفات رسمياً في قاعدة البيانات. يمكنك الآن تجهيز رسائل SMS وإرسالها للمكلفين.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        showSuccessApproveDialog = false
                        existingPlan?.let { onPrepareSms(it.id, selectedDate) }
                        onNavigateToSms()
                    }
                ) {
                    Text("تجهيز وإرسال رسائل SMS")
                }
            },
            dismissButton = {
                TextButton(onClick = { showSuccessApproveDialog = false }) {
                    Text("إغلاق")
                }
            }
        )
    }
}
