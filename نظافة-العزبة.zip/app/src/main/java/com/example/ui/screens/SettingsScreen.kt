package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SimCard
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.preferences.AppPreferences

@Composable
fun SettingsScreen(preferences: AppPreferences) {
    val context = LocalContext.current

    var defaultDueTime by remember { mutableStateOf(preferences.defaultDueTime) }
    var maxDailyTasks by remember { mutableStateOf(preferences.maxDailyTasksPerPerson.toString()) }
    var maxDailyEffort by remember { mutableStateOf(preferences.maxDailyEffortPoints.toString()) }
    var maxSmsRetry by remember { mutableStateOf(preferences.maxSmsRetryCount.toString()) }
    var assignmentTemplate by remember { mutableStateOf(preferences.assignmentTemplate) }
    var reminderTemplate by remember { mutableStateOf(preferences.reminderTemplate) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("settings_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Settings,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إعدادات وقواعد التوزيع والعمل",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = defaultDueTime,
                        onValueChange = { defaultDueTime = it },
                        label = { Text("الموعد الافتراضي للتكليف اليومي") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = maxDailyTasks,
                            onValueChange = { maxDailyTasks = it.filter { ch -> ch.isDigit() } },
                            label = { Text("الحد الأقصى للمهام/فرد") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = maxDailyEffort,
                            onValueChange = { maxDailyEffort = it.filter { ch -> ch.isDigit() } },
                            label = { Text("الحد الأقصى للجهد/فرد") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // SMS Settings Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Message,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.secondary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إعدادات وقوالب رسائل SMS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = maxSmsRetry,
                        onValueChange = { maxSmsRetry = it.filter { ch -> ch.isDigit() } },
                        label = { Text("الحد الأقصى لمحاولات إعادة الإرسال") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = assignmentTemplate,
                        onValueChange = { assignmentTemplate = it },
                        label = { Text("قالب رسالة التكليف الجديد") },
                        maxLines = 6,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = reminderTemplate,
                        onValueChange = { reminderTemplate = it },
                        label = { Text("قالب رسالة التذكير للمهام غير المكتملة") },
                        maxLines = 5,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }
        }

        // Save Button
        item {
            Button(
                onClick = {
                    preferences.defaultDueTime = defaultDueTime
                    preferences.maxDailyTasksPerPerson = maxDailyTasks.toIntOrNull() ?: 2
                    preferences.maxDailyEffortPoints = maxDailyEffort.toIntOrNull() ?: 4
                    preferences.maxSmsRetryCount = maxSmsRetry.toIntOrNull() ?: 4
                    preferences.assignmentTemplate = assignmentTemplate
                    preferences.reminderTemplate = reminderTemplate

                    Toast.makeText(context, "تم حفظ الإعدادات بنجاح!", Toast.LENGTH_SHORT).show()
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("حفظ التغييرات")
            }
        }

        // Dual SIM & Security Guidance Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.SimCard, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الأجهزة ثنائية الشريحة (Dual SIM)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "يتم إرسال الرسائل عبر الشريحة الافتراضية لرسائل SMS المحددة في إعدادات هاتف أندرويد. في حال الرغبة في التبديل، يمكنك استخدام زر «فتح في تطبيق الرسائل» لاختيار الشريحة يدوياً.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "الأمان والخصوصية (NFR-08)",
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.titleSmall
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "كافة البيانات والنسخ الاحتياطية مخزنة محلياً بالكامل على جهاز المسؤول (Offline-first) ولا يتم إرسال أي أرقام أو بيانات خارج الهاتف. يُوصى بتفعيل قفل الهاتف لضمان حماية سجلات العزبة.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
