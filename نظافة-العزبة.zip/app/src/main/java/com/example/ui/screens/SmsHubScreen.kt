package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.HourglassEmpty
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.QuestionMark
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.entity.PersonEntity
import com.example.data.local.entity.SmsOutboxEntity
import com.example.domain.model.SmsStatus
import com.example.platform.sms.SmsManagerHelper
import com.example.ui.theme.StatusError
import com.example.ui.theme.StatusNeutral
import com.example.ui.theme.StatusSuccess
import com.example.ui.theme.StatusWarning

@Composable
fun SmsHubScreen(
    outboxMessages: List<SmsOutboxEntity>,
    peopleById: Map<String, PersonEntity>,
    onSendDirect: (SmsOutboxEntity) -> Unit,
    onRetryMessage: (String) -> Unit,
    onMarkUnknown: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedStatusFilter by remember { mutableStateOf<String?>(null) }
    var showTestSmsDialog by remember { mutableStateOf(false) }

    // Launcher for SEND_SMS permission
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            Toast.makeText(context, "تم منح إذن إرسال SMS بنجاح.", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                context,
                "تم رفض إذن SMS. يمكنك استخدام زر «فتح في تطبيق الرسائل» كبديل مباشر.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    val filteredList = remember(outboxMessages, selectedStatusFilter) {
        if (selectedStatusFilter == null) outboxMessages
        else outboxMessages.filter { it.status == selectedStatusFilter }
    }

    val queuedCount = outboxMessages.count { it.status == "QUEUED" || it.status == "RETRY_WAIT" }
    val sentCount = outboxMessages.count { it.status == "SENT" || it.status == "DELIVERED" }
    val failedCount = outboxMessages.count { it.status == "FAILED" }
    val unknownCount = outboxMessages.count { it.status == "UNKNOWN" }

    var isBatchSending by remember { mutableStateOf(false) }
    var showBatchPreviewDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("sms_hub_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // 1. Header & Test Action
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "مركز رسائل التكليفات (SMS)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "مراقبة صندوق الانتظار ونتائج الإرسال وبدائل النظام",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Button(
                            onClick = { showTestSmsDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primary
                            )
                        ) {
                            Text("رسالة تجريبية")
                        }
                    }

                    if (queuedCount > 0) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            if (!isBatchSending) {
                                Button(
                                    onClick = { showBatchPreviewDialog = true },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = MaterialTheme.colorScheme.secondary
                                    )
                                ) {
                                    Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("معاينة وإرسال للكل ($queuedCount)")
                                }
                            } else {
                                Button(
                                    onClick = { isBatchSending = false },
                                    modifier = Modifier.weight(1f),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = StatusError
                                    )
                                ) {
                                    Icon(Icons.Default.Error, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("إيقاف الإرسال مؤقتاً")
                                }
                            }
                        }
                    }
                }
            }
        }

        // 2. Status Filter Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    FilterChip(
                        selected = selectedStatusFilter == null,
                        onClick = { selectedStatusFilter = null },
                        label = { Text("الكل (${outboxMessages.size})") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "QUEUED",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "QUEUED") null else "QUEUED" },
                        label = { Text("في الانتظار ($queuedCount)") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "SENT",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "SENT") null else "SENT" },
                        label = { Text("تم الإرسال ($sentCount)") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "FAILED",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "FAILED") null else "FAILED" },
                        label = { Text("فشل ($failedCount)") }
                    )
                }
                item {
                    FilterChip(
                        selected = selectedStatusFilter == "UNKNOWN",
                        onClick = { selectedStatusFilter = if (selectedStatusFilter == "UNKNOWN") null else "UNKNOWN" },
                        label = { Text("غير محسوم ($unknownCount)") }
                    )
                }
            }
        }

        // 3. Message Cards
        if (filteredList.isEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    ),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.HourglassEmpty,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "لا توجد رسائل في هذا التصنيف",
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "تظهر الرسائل هنا تلقائياً عند تجهيز رسائل جدول اليوم المعتمد.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredList) { msg ->
                val person = peopleById[msg.personId]
                var isExpanded by remember { mutableStateOf(false) }

                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = person?.name ?: "مستلم غير معروف",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = msg.recipientPhoneSnapshot,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(
                                        when (msg.status) {
                                            "SENT", "DELIVERED" -> StatusSuccess.copy(alpha = 0.12f)
                                            "FAILED" -> StatusError.copy(alpha = 0.12f)
                                            "UNKNOWN" -> StatusNeutral.copy(alpha = 0.12f)
                                            else -> StatusWarning.copy(alpha = 0.12f)
                                        }
                                    )
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                val label = try {
                                    SmsStatus.valueOf(msg.status).labelAr
                                } catch (_: Exception) {
                                    msg.status
                                }
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (msg.status) {
                                        "SENT", "DELIVERED" -> StatusSuccess
                                        "FAILED" -> StatusError
                                        "UNKNOWN" -> StatusNeutral
                                        else -> StatusWarning
                                    }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Message Text Box
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(10.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                                .clickable { isExpanded = !isExpanded }
                                .padding(10.dp)
                        ) {
                            Text(
                                text = if (isExpanded) msg.bodySnapshot else msg.bodySnapshot.take(90) + if (msg.bodySnapshot.length > 90) "... (انقر للمزيد)" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        if (!msg.lastErrorMessage.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "سبب الخطأ: ${msg.lastErrorMessage}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusError
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Action Buttons: Direct SMS vs Fallback SMS App
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            // Direct Send button
                            Button(
                                onClick = {
                                    if (!SmsManagerHelper.hasSmsPermission(context)) {
                                        permissionLauncher.launch(android.Manifest.permission.SEND_SMS)
                                    } else {
                                        onSendDirect(msg)
                                    }
                                },
                                modifier = Modifier.weight(1f),
                                enabled = msg.status != "SENT"
                            ) {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("إرسال بالنظام", fontSize = 12.sp)
                            }

                            // Fallback: Open Default SMS App Intent
                            OutlinedButton(
                                onClick = {
                                    val intent = SmsManagerHelper.openSmsAppIntent(
                                        context,
                                        msg.recipientPhoneSnapshot,
                                        msg.bodySnapshot
                                    )
                                    context.startActivity(intent)
                                },
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("تطبيق الرسائل", fontSize = 12.sp)
                            }

                            // Retry / Unknown Actions
                            if (msg.status == "FAILED" || msg.status == "RETRY_WAIT" || msg.status == "UNKNOWN") {
                                OutlinedButton(
                                    onClick = { onRetryMessage(msg.id) },
                                    modifier = Modifier.weight(0.7f)
                                ) {
                                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }

                            if (msg.status == "SENDING" || msg.status == "FAILED") {
                                OutlinedButton(
                                    onClick = { onMarkUnknown(msg.id) },
                                    modifier = Modifier.weight(0.7f)
                                ) {
                                    Icon(Icons.Default.QuestionMark, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Test SMS Dialog
    if (showTestSmsDialog) {
        var testPhone by remember { mutableStateOf("") }
        var testBody by remember { mutableStateOf("رسالة اختبار من تطبيق نظافة العزبة: النظام جاهز ومفعل.") }

        AlertDialog(
            onDismissRequest = { showTestSmsDialog = false },
            title = { Text("إرسال رسالة اختبار SMS") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "يمكنك اختبار الإرسال على رقمك الشخصي للتأكد من عمل الشبكة والشريحة.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    OutlinedTextField(
                        value = testPhone,
                        onValueChange = { testPhone = it },
                        label = { Text("رقم الهاتف للتجربة") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = testBody,
                        onValueChange = { testBody = it },
                        label = { Text("نص الرسالة") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (testPhone.isBlank()) return@Button
                        if (!SmsManagerHelper.hasSmsPermission(context)) {
                            permissionLauncher.launch(android.Manifest.permission.SEND_SMS)
                        } else {
                            val (success, err) = SmsManagerHelper.sendDirectSms(context, testPhone, testBody)
                            if (success) {
                                Toast.makeText(context, "تم إرسال الرسالة التجريبية بنجاح!", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "فشل الإرسال: $err", Toast.LENGTH_LONG).show()
                            }
                        }
                        showTestSmsDialog = false
                    }
                ) {
                    Text("إرسال عبر النظام")
                }
            },
            dismissButton = {
                Row {
                    TextButton(
                        onClick = {
                            if (testPhone.isNotBlank()) {
                                val intent = SmsManagerHelper.openSmsAppIntent(context, testPhone, testBody)
                                context.startActivity(intent)
                            }
                            showTestSmsDialog = false
                        }
                    ) {
                        Text("فتح في التطبيق")
                    }
                    TextButton(onClick = { showTestSmsDialog = false }) {
                        Text("إلغاء")
                    }
                }
            }
        )
    }

    // Batch Preview Dialog (FR-05 & Section 10: معاينة عدد المستلمين ونص الرسالة قبل الإرسال الجماعي)
    if (showBatchPreviewDialog) {
        val queuedList = outboxMessages.filter { it.status == "QUEUED" || it.status == "RETRY_WAIT" }
        AlertDialog(
            onDismissRequest = { showBatchPreviewDialog = false },
            title = { Text("معاينة الإرسال الجماعي (${queuedList.size} رسالة)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "سيتم إرسال تكليفات اليوم إلى ${queuedList.size} فرد عبر شبكة SMS.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "عينة من نص الرسالة:",
                        fontWeight = FontWeight.Bold,
                        style = MaterialTheme.typography.bodySmall
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(8.dp)
                    ) {
                        Text(
                            text = queuedList.firstOrNull()?.bodySnapshot ?: "",
                            fontSize = 11.sp
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showBatchPreviewDialog = false
                        if (!SmsManagerHelper.hasSmsPermission(context)) {
                            permissionLauncher.launch(android.Manifest.permission.SEND_SMS)
                        } else {
                            isBatchSending = true
                            queuedList.forEach { msg ->
                                onSendDirect(msg)
                            }
                            isBatchSending = false
                            Toast.makeText(context, "تم إرسال جميع الرسائل إلى الشبكة بنجاح!", Toast.LENGTH_SHORT).show()
                        }
                    }
                ) {
                    Text("تأكيد وإرسال الكل")
                }
            },
            dismissButton = {
                TextButton(onClick = { showBatchPreviewDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

