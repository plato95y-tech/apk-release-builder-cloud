package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Primary: Deep Emerald
val EmeraldPrimaryLight = Color(0xFF1B5E20)
val EmeraldOnPrimaryLight = Color(0xFFFFFFFF)
val EmeraldContainerLight = Color(0xFFA5D6A7)
val EmeraldOnContainerLight = Color(0xFF002204)

val EmeraldPrimaryDark = Color(0xFF81C784)
val EmeraldOnPrimaryDark = Color(0xFF00390B)
val EmeraldContainerDark = Color(0xFF154B1A)
val EmeraldOnContainerDark = Color(0xFFA5D6A7)

// Secondary: Clean Teal
val TealSecondaryLight = Color(0xFF00695C)
val TealOnSecondaryLight = Color(0xFFFFFFFF)
val TealContainerLight = Color(0xFFB2DFDB)
val TealOnContainerLight = Color(0xFF00201B)

val TealSecondaryDark = Color(0xFF80CBC4)
val TealOnSecondaryDark = Color(0xFF003730)
val TealContainerDark = Color(0xFF004D40)
val TealOnContainerDark = Color(0xFFB2DFDB)

// Tertiary: Warm Gold / Amber Accent
val AmberTertiaryLight = Color(0xFFF57F17)
val AmberOnTertiaryLight = Color(0xFFFFFFFF)
val AmberContainerLight = Color(0xFFFFF9C4)
val AmberOnContainerLight = Color(0xFF261900)

val AmberTertiaryDark = Color(0xFFFFD54F)
val AmberOnTertiaryDark = Color(0xFF3F2E00)
val AmberContainerDark = Color(0xFF5C4300)
val AmberOnContainerDark = Color(0xFFFFE082)

// Background & Surfaces
val BackgroundLight = Color(0xFFF7FAF7)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE8EFE8)
val OutlineLight = Color(0xFF727970)

val BackgroundDark = Color(0xFF111511)
val SurfaceDark = Color(0xFF181D18)
val SurfaceVariantDark = Color(0xFF242A24)
val OutlineDark = Color(0xFF8C938A)

// Status Colors
val StatusSuccess = Color(0xFF2E7D32)
val StatusWarning = Color(0xFFEF6C00)
val StatusError = Color(0xFFC62828)
val StatusNeutral = Color(0xFF546E7A)
