package com.example

import com.example.backup.BackupManager
import com.example.data.local.entity.CleaningTaskEntity
import com.example.data.local.entity.DailyAssignmentEntity
import com.example.data.local.entity.PersonEntity
import com.example.domain.scheduler.FairScheduler
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class FairSchedulerTest {

    @Test
    fun testHardConstraint_absentAndInactivePeopleExcluded() {
        val people = listOf(
            PersonEntity(id = "p1", name = "محمد", phoneNumber = "0501", isActive = true),
            PersonEntity(id = "p2", name = "خالد", phoneNumber = "0502", isActive = false), // Inactive
            PersonEntity(id = "p3", name = "عبدالله", phoneNumber = "0503", isActive = true)
        )
        val absentIds = setOf("p3") // Absent

        val tasks = listOf(
            CleaningTaskEntity(
                id = "t1",
                areaId = "a1",
                name = "كنس المجلس",
                effortPoints = 1,
                requiredPeople = 1
            )
        )

        val proposal = FairScheduler.generateProposal(
            date = "2026-10-22",
            activePeople = people,
            absentPersonIds = absentIds,
            tasks = tasks,
            areaNamesById = mapOf("a1" to "المجلس"),
            past14DaysAssignments = emptyList(),
            yesterdayDate = "2026-10-21"
        )

        // Only p1 is active and not absent!
        assertEquals(1, proposal.proposedAssignments.size)
        assertEquals("p1", proposal.proposedAssignments[0].personId)
    }

    @Test
    fun testUncoveredTasks_whenInsufficientPeople() {
        val people = listOf(
            PersonEntity(id = "p1", name = "محمد", phoneNumber = "0501", isActive = true)
        )

        val tasks = listOf(
            CleaningTaskEntity(
                id = "t1",
                areaId = "a1",
                name = "تنظيف عميق",
                effortPoints = 3,
                requiredPeople = 2 // Needs 2, but only 1 available!
            )
        )

        val proposal = FairScheduler.generateProposal(
            date = "2026-10-22",
            activePeople = people,
            absentPersonIds = emptySet(),
            tasks = tasks,
            areaNamesById = mapOf("a1" to "المجلس"),
            past14DaysAssignments = emptyList(),
            yesterdayDate = "2026-10-21"
        )

        assertEquals(0, proposal.proposedAssignments.size)
        assertEquals(1, proposal.uncoveredTasks.size)
        assertEquals("t1", proposal.uncoveredTasks[0].taskId)
    }

    @Test
    fun testEffortBalancing_prefersPersonWithLessEffort() {
        val p1 = PersonEntity(id = "p1", name = "محمد", phoneNumber = "0501", isActive = true)
        val p2 = PersonEntity(id = "p2", name = "عبدالله", phoneNumber = "0502", isActive = true)

        // Give p1 6 points in past 14 days, p2 has 0 points
        val pastAssignments = listOf(
            DailyAssignmentEntity(
                planId = "pl1",
                taskId = "t_old",
                personId = "p1",
                assignmentDate = "2026-10-20",
                effortPointsSnapshot = 6
            )
        )

        val task = CleaningTaskEntity(
            id = "t1",
            areaId = "a1",
            name = "مهمة متوسطة",
            effortPoints = 2,
            requiredPeople = 1
        )

        val proposal = FairScheduler.generateProposal(
            date = "2026-10-22",
            activePeople = listOf(p1, p2),
            absentPersonIds = emptySet(),
            tasks = listOf(task),
            areaNamesById = mapOf("a1" to "المجلس"),
            past14DaysAssignments = pastAssignments,
            yesterdayDate = "2026-10-21"
        )

        // p2 should be chosen because p2 has 0 effort points vs p1 with 6 points
        assertEquals("p2", proposal.proposedAssignments[0].personId)
    }

    @Test
    fun testBackupInspection_validatesSchema() {
        val validJson = """
            {
              "schemaVersion": 1,
              "exportedAt": "2026-10-22T10:00:00Z",
              "appVersion": "1.0.0",
              "data": {
                "people": [{"id": "1", "name": "أحمد"}],
                "areas": [],
                "tasks": []
              }
            }
        """.trimIndent()

        val preview = BackupManager.inspectBackup(validJson)
        assertTrue(preview.isValid)
        assertEquals(1, preview.schemaVersion)
        assertEquals(1, preview.peopleCount)

        val invalidJson = """{"invalid": true}"""
        val invalidPreview = BackupManager.inspectBackup(invalidJson)
        assertFalse(invalidPreview.isValid)
    }
}
